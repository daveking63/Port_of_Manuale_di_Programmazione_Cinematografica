// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/slumdog_millionaire
// Date: 2015
// Description: Slumdog millionaire (2008)

let PAPER;
let INK1;
let INK2;

function  setup() {
	createCanvas(480, 640);
	PAPER = color(0, 0, 0);
	INK1 = color(120, 60, 255);
	INK2 = color(225, 225, 225);
	noLoop();
}

function draw() {
  	background(PAPER);
  	
	translate(width/2.0, 2*height/3.0);
	stroke(INK2);
	strokeWeight(3.0);
	fill(INK1);

	line(-width/2.0, -100, width/2.0, -100);
	line(-width/2.0,    0, width/2.0,    0);
	line(-width/2.0,  100, width/2.0,  100);

	drawCell(         0, -100, 400, 50);
	drawCell(-width/4.0,    0, 150, 50);
	drawCell( width/4.0,    0, 150, 50);
	drawCell(-width/4.0,  100, 150, 50);
	drawCell( width/4.0,  100, 150, 50);
  
}

function drawCell(x, y, w, h) {
  
	push();
	translate(x, y);
	let w2 = float(w/2.0);
	let h2 = float(h/2.0);
		beginShape();
			vertex(-w2,      0);
			vertex(-w2+10, -h2);
			vertex( w2-10, -h2);
			vertex( w2,      0);
			vertex( w2-10,  h2);
			vertex(-w2+10,  h2);
			vertex(-w2,      0);
		endShape();
	pop();
}

function keyTypes(){
	if (key=='s'){save("slumdog-millionaire.png")}
}
