// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/ring_the
// Date: 2019
// Description: The Ring (2002)

let PAPER, INK;
let ALPHA;
let COUNT = 15;
let OFFSET = 0.02;
let WEIGHT = 5;
let RADIUS = 0.5;

function setup() {
  createCanvas(480, 640);
  PAPER = color(0);
  INK = color(255);
  ALPHA = 100.0;
  noLoop();
}


function draw() {
  
  let U = float(0.002);
  let S = float(min(width, height));
  
  translate(0.5*width, 0.5*height);
  scale(S);
  
  randomSeed(0);
  
  background(PAPER);
  
  noFill();
  stroke(INK, ALPHA);
  strokeWeight(WEIGHT*U);
  
  for (let i=0; i<COUNT; i++) {
    let dx = random(-OFFSET, +OFFSET);
    let dy = random(-OFFSET, +OFFSET);
    ellipse(dx, dy, RADIUS, RADIUS);
  }

}
