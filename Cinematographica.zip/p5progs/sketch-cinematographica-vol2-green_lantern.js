// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/green_lantern
// Date: 2016
// Description: Green Lantern (2011)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(10, 110, 40);
	INK = color(255);
	noLoop();
}

function draw() {
  background(PAPER);
  
  let s = float(0.7 * min(width, height));
  
  translate(width/2.0, height/2.0);
  noStroke();
  fill(INK);
  ellipse(0, 0, s, s);
  
  fill(PAPER);
  ellipse(0, 0, 0.5*s, 0.5*s);
  
  fill(INK);
  ellipse(0, 0, 0.3*s, 0.3*s);
  
  stroke(PAPER);
  strokeWeight(0.1*s);
  strokeCap(SQUARE);
  
  line(-0.3*s, -0.25*s, 0.3*s, -0.25*s);
  line(-0.3*s,  0.25*s, 0.3*s,  0.25*s);
  
}

function keyTypes(){
	if (key=='s'){save("green-lantern.png")}
}