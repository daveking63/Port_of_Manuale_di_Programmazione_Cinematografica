// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/thor
// Date: 2016
// Description: Thor (2011)

let PAPER;
let INK;
let STRIPES = 6;

function setup() {
	createCanvas(480, 640);
	PAPER = color(105, 10, 170);
	INK = color(255, 205, 0);
	noLoop();
}

function draw() {
	background(PAPER);
	let s = float(0.6 * min(width, height));
	translate(width/2.0, height/4.0);
	fill(INK);
	stroke(PAPER);
	strokeWeight(0.01*s);
	rectMode(CENTER);
	rect(0, 0.5*s, 0.2*s, 1.6*s, 0.05*s);
	rect(0, 0, s, 0.5*s, 0.1*s);

	stroke(PAPER);
	line(-0.25*width, -height, -0.25*width, height);
	line( 0.25*width, -height,  0.25*width, height);

	translate(0, 0.6*s);
	strokeWeight(0.02*s);

	for (let i=0; i<STRIPES; i++) {
		let d = 0.1*s;
		line(-d, i*d, d, (i+1)*d);
	}
}

function keyTypes(){
	if (key=='s'){save("thor.png")}
}  