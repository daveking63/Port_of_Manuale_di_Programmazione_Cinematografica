// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/x_2001_a_space_odyssey
// Date: 20159
// Description: 2001 A Space Odyssey (1968)

let PAPER;
let INK1;
let INK2;

function setup()  {
	createCanvas(480, 640, WEBGL);
	PAPER = color(255,228,181);
	INK1 = color(0);
	INK2 = color(64);
	smooth(8);
	noLoop();
}

function draw()  {
	background(PAPER);
	
	let fov = float(PI/3.0);
	let camZ = float((height/2.0) / tan(fov/2.0)); 
	let aspect =  float(width)/float(height);
	perspective(fov, aspect, camZ/2.0, camZ*2.0); 
	//lights(); not working in p5.js
	
	//translate(width/2.0, height/2.0, 0); this is the default for WEBGL
	rotateX(-PI/6); 
	rotateY(PI/3);



	fill(INK1);
	stroke(INK2);
	strokeWeight(2.0); 
	box(40, 360, 160); 

}

function keyTypes(){
	if (key=='s'){save("2001-a-space-odyssey.png")}
}
