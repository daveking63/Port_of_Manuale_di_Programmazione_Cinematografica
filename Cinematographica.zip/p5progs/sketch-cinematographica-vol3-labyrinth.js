// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/labyrinth
// Date: 2015
// Description: Labyrinth (1986)

// Adventure, Family, Fantasy
// http://www.imdb.com/title/tt0091369/
// See also:
// 10 PRINT CHR$(205.5+RND(1)); : GOTO 10

let PAPER;
let INK;
let SCALE = 30.0;
let STROKE = 6.0;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255, 235, 130);
	INK = color(30);
	noLoop();
}

function draw() {
	background(PAPER);

	let MAX_X = float(width/SCALE);
	let MAX_Y = float(height/SCALE);
	scale(SCALE);
	noFill();
	stroke(INK);
	strokeCap(ROUND);
	strokeWeight(STROKE / SCALE);

	randomSeed(7);

	for (let x=0; x<MAX_X; x++) {
		for (let y=0; y<MAX_Y; y++) {
			let r = random(1);
			line(x + int(0.5+r), y, x + int(1.5-r), y+1);
		}
	}
}

function keyTypes(){
	if (key=='s'){save("labyrinth.png")}
}
