// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/back_to_the_future
// Date: 2018
// Description: Back to the Future (1985)

let PAPER;
let INK;
let A1;
let A2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(20, 20, 75);
	INK = color(255, 125, 35);
	A1 = HALF_PI;
	A2 = HALF_PI + QUARTER_PI;
	noLoop();
}

function draw() {
	background(PAPER);
	let S =  float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.5*height);
	scale(S);
	rotate(HALF_PI);

	for (let i=0; i<3; i++) {
		stroke(INK);
		strokeWeight(10*U);
		line(0.0, 0.0, 0.3, 0.0);
		fill(INK);
		noStroke();
		ellipse(0.3, 0.0, 0.08, 0.08);
		noFill();
		stroke(INK);
		strokeWeight(12*U);
		ellipse(0.3, 0.0, 0.2, 0.2);
		rotate((i%2 == 0) ? A2 : A1);
	}
}

function keyTypes(){
	if (key=='s'){save("back-to-the-future.png")}
}  