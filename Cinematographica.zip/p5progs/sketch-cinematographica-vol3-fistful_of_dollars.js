// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/fistful_of_dollars
// Date: 2015
// Description: Fistful of dollars (1964)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(55, 50, 0);
	INK = color(170, 165, 120);
	noLoop();
}

function draw() {
	background(PAPER);
	
	translate(width/2.0, 0);
	strokeWeight(20);
	stroke(INK);
	noFill();

	rectMode(CENTER);
	rect(-200,   0, 50, 50);
	rect(-150,  50, 50, 50);
	rect(-100, 100, 50, 50);
	rect( -50, 150, 50, 50);

	rect(   0, 200, 50, 50);

	rect( 50, 150, 50, 50);
	rect(100, 100, 50, 50);
	rect(150, 50, 50, 50);
	rect(200, 0, 50, 50);

	strokeCap(SQUARE);

	line(-150, 250, -200, 250);
	line(-200, 240, -200, 290);
	line(-200, 280, -75, 280);
	line(-85, 270, -85, 320);
	line(-75, 310, -125, 310);

	line(150, 250, 200, 250);
	line(200, 240, 200, 290);
	line(200, 280, 75, 280);
	line(85, 270, 85, 320);
	line(75, 310, 125, 310);

	line(-25, 50, 25, 50);
	line(-60, 25, -10, 25);
	line( 60, 25, 10, 25);

	line(-25, 400, 25, 400);
	line(200, 500, 150, 500);
	line(-200, 500, -150, 500);
	line(-25, 600, 25, 600);
}

function keyTypes(){
	if (key=='s'){save("fistful-of-dollars.png")}
}