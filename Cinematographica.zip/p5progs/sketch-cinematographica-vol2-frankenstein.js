// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/frankenstein
// Date: 2016
// Description: Frankenstein (1931)

let PAPER;
let INK1;
let INK2;
let STEPS = 15;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255, 225, 190);
	INK1 = color(255, 205, 150);
	INK2 = color(35);
	noLoop();
}


function draw() {

	background(PAPER);

	fill(INK1);
	noStroke();

	quad(0, 0, width, 0, width, height/3.0, 0, height/2.0);

	let dx = float(width / STEPS);
	let dy = float((height/3.0 - height/2.0) / STEPS);

	let s = float(0.05 * min(width, height));
	let d = float(0.4 * s);

	stroke(INK2);
	strokeWeight(s/5);

	for (let i=1; i<STEPS; i++) {
		let x = float(i*dx);
		let y = float(height/2.0 + i*dy);
		line(x+random(-d , d), y-s, x+random(-d, d), y+s);
	}

}
function keyTypes(){
	if (key=='s'){save("frankenstein.png")}
}