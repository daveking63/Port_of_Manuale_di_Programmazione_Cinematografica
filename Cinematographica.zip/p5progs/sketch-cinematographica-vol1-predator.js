// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/predator
// Date: 2016
// Description: Predator (1987)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(65, 45, 35);
	INK = color(175, 10, 10);
	noLoop();
}

function draw() {
	background(PAPER);
	
	translate(width/2.0, height/3.0);
	fill(INK);
	noStroke();
	rotate(-PI/2);  

	for (let i=0; i<3; i++) {
		rotate(TWO_PI / 3);
		ellipse(75, 0, 50, 50);
	}
}
function keyTypes(){
	if (key=='s'){save('predator.png')}
}