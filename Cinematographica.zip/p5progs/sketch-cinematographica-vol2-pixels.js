// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/pixels
// Date: 2015
// Description: Pixels (2015)

let PAPER;
let INK1;
let INK2;
let SIZE = 10;
let DOTS = 8;

function setup() {
	createCanvas(480, 640);
	PAPER = color(32);
	INK1 = color(250, 175, 145);
	INK2 = color(255, 245, 0);
	noLoop();
}

function draw() {
	background(PAPER);

	translate(width/2.0, height/2.0);
	scale(SIZE);
	stroke(INK1);

	for (let i=0; i<DOTS; i++) {
		point(i*3, 0);
	}

	noStroke();
	fill(INK2);
	arc(-SIZE/2, 0, SIZE, SIZE, QUARTER_PI, TWO_PI-QUARTER_PI, PIE);
}

function keyTypes(){
if (key=='s'){save("pixels.png")}
}
