// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/kill_bill
// Date: 2015
// Description: Kill Bill (2003)


let PAPER;
let INK;
let SIZE = 50;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255, 195, 25);
	INK = color(30);
	noLoop();
}

function draw() {
	background(PAPER);

	stroke(INK);
	strokeWeight(SIZE);
	line(2*SIZE, 0, 2*SIZE, height);
}

function keyTypes(){
	if (key=='s'){save("kill-bill.png")}
}