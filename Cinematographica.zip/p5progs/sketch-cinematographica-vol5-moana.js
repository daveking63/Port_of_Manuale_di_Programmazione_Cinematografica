// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/moana
// Date: 2016
// Description: Moana (2016)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640, P2D);
	PAPER = color(225, 205, 160);
	INK = color(160, 40, 25);
	smooth(8);
	noLoop();
}

function draw() {
	background(PAPER);

	let S =  float(min(width, height));
	let U = 0.002;
	let T = 30.0*U;

	translate(0.5*width, 0.5*height);
	scale(S);
	fill(INK);  
	noStroke();

	for (let a=0.0; a<2.6*PI; a+=0.1*T) {
		let x = float(0.06*a*cos(a));
		let y = float(0.06*a*sin(a));
		ellipse( x,  y, T, T);
		ellipse(-x, -y, T, T);
	}
}

function keyTypes(){
	if (key=='s'){save("moana.png")}
}  