// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/alice_in_wonderland
// Date: 2016
// Description: Alice in Wonderland (1951)

let PAPER;
let INK;

let L = 0.625;
let COUNT = 8;

function setup() {
	createCanvas(480, 640);
	PAPER = color(230, 145, 170);
	INK = color(245);
	noLoop();
}


function draw() {
	background(PAPER);
	
	let S =  min(width, height);
	let U = 0.002;

	translate(0.5*width, 0.3*height);
	scale(S);
	noStroke();
	fill(INK);
	ellipse(0, 0, L, L);

	fill(PAPER);
	ellipse(0, -0.17*L, 1.08*L, L);

	stroke(PAPER);
	strokeWeight(U);
	for (let i=-L; i<L; i+=L/COUNT) {
		line(i, 0, i, 1.5); 
	}
}

function keyTypes(){
	if (key=='s'){save('alice-in-wonderland.png')}
}