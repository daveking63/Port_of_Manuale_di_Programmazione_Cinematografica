// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/blood_diamond
// Date: 2016
// Description: Blood Diamond (2006)

let PAPER;
let INK1;
let INK2;
let L = 0.08;

function setup() {
	createCanvas(480, 640);
	PAPER = color(120);
	INK1 = color(255, 235, 230);
	INK2 = color(165, 10, 30);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let S = min(width, height);
	let U = 0.002;

	translate(0.5*width, 0.3*height);
	scale(S);
	noStroke();
	fill(INK1);

	beginShape();
		vertex(-3*L,  -L);
		vertex( 3*L,  -L);
		vertex( 4*L, 0.0);
		vertex( 0.0, 5*L);
		vertex(-4*L, 0.0);
	endShape(CLOSE);

	translate(0, 7*L);
	fill(INK2);
	triangle(0, -1.4*L, 0.52*L, 0, -0.52*L, 0);
	ellipse(0, 0, L, L);
  
}

function keyTypes(){
if (key=='s'){save("blood-diamond.png")}
}