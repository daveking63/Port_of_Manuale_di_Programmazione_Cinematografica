// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/spiderman
// Date: 2016
// Description: Spider-man (2002)

let PAPER;
let INK1;
let INK2;
let LINES = 5;


function setup() {
	createCanvas(480, 640);
	PAPER = color(135, 0, 0);
	INK1 = color(0);
	INK2 = color(240);
	noLoop();
}


function draw() {
	background(PAPER);
	let s = float(0.01 * min(width, height));

	translate(0.5*width, 0.5*height);
	stroke(INK1);
	fill(INK2);
	strokeWeight(0.5*s);

	for (let i=0; i<LINES; i++) {
		rotate(PI/(LINES+1));
		line(-width, 0, +width, 0);
	}

	strokeWeight(s); 
	resetMatrix();
	translate(width/2.0, height/2.0);

	triangle( 5*s, 0,  width, -height/3,  width, 20*s);
	triangle(-5*s, 0, -width, -height/3, -width, 20*s);
}

function keyTypes(){
	if (key=='s'){save("spider-man.png")}
}  