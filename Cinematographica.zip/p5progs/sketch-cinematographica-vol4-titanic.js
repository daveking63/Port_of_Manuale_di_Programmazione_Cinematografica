// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/titanic
// Date: 20196
// Description: Titanic (1997)

let PAPER;
let INK1;
let INK2;
let INK3;
let INK4;


function setup() {
	createCanvas(480, 640);
	PAPER = color(0, 35, 60);
	INK1 = color(10, 10, 20);
	INK2 = color(50, 60, 80);
	INK3 = color(240);
	INK4 = color(50, 80, 135, 100);
	noLoop();
}


function draw() {
	background(PAPER);

	translate(0.5*width, 0.7*height);
	scale(min(width, height));
	noStroke();
	fill(INK1);
	quad(0.0, -0.85, -0.1, -0.77, 0.0, 0.0, 0.1, -0.77);
	quad(0.0, -0.7,  0.3, -0.5,  0.2, 0.0, 0.0, 0.0);

	fill(INK2);
	quad(0.0, -0.7, -0.3, -0.5, -0.2, 0.0, 0.0, 0.0);

	fill(INK3);
	beginShape();
		vertex(-0.2,  0.0);
		vertex(-0.1, -0.5);
		vertex( 0.0, -0.2);
		vertex( 0.1, -0.3);
		vertex( 0.2,  0.0);
		vertex( 0.0,  0.2);
	endShape(CLOSE);

	fill(INK4);
	rect(-0.5, -0.15, width, height);
}

function keyTypes(){
	if (key=='s'){save("titanic.png")}
}  