// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/dukes_of_hazzard_the
// Date: 2015
// Description: The Dukes of Hazzard (2005)

let PAPER;
let INK1;
let INK2;
let S = 8;

function setup() {
	createCanvas(480, 640);
	PAPER = color(250, 0, 0);
	INK1 = color(255);
	INK2 = color(15, 0, 100);
	noLoop();
}

function draw() {
	background(PAPER);

	stroke(INK1);
	strokeWeight(120.0);
	line(0, 0, width, height);
	line(width, 0, 0, height);

	stroke(INK2);
	strokeWeight(100.0);
	line(0, 0, width, height);
	line(width, 0, 0, height);

	fill(INK1);
	noStroke();
	for (let i=1; i<S; i++) {
		star(i*width/S, i*height/S, 0.5);
		star((S-i)*width/S, i*height/S, 0.5);
	}
}

function star(x, y, createcanvas) {
	push();
	translate(x, y);
	scale(createcanvas, createcanvas);
	beginShape();
		vertex(0, -50);
		vertex(29, 40);
		vertex(-47, -15);
		vertex(47, -15);
		vertex(-29, 40);
	endShape(CLOSE);
	pop();
}

function keyTypes(){
	if (key=='s'){save("the-dukes-of-hazzard.png")}
}