// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/charlie_s_angels
// Date: 2016
// Description: Charlie's Angels(2000)

let PAPER;
let INK1;
let INK2;

let W = 100.0;
let H = 60.0;
 
function setup() {
	createCanvas(480, 640);
	PAPER = color(245, 180, 50);
	INK1 = color(100, 60, 20);
	INK2 = color(200);
	noLoop();
}

function draw() {
	background(PAPER);
	
	translate(width/2.0, 3*height/5.0);
	stroke(INK1);
	fill(INK2);
	strokeWeight(10.0);
	strokeJoin(ROUND);

	quad(-W, -H, W, -H, 1.1*W, H, -1.1*W, H);

	fill(INK1);
	noStroke();
	for (let i=1; i<20; i++) {
		for (let j=3; j<10; j++) {
			ellipse(-W+i*10, -H+j*10, 5, 5);
		}
	}
}

function keyTypes(){
	if (key=='s'){save("charlies_s_angels.png")}
}