// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/pianist_the
// Date: 2016
// Description: The Pianist (2002)

let PAPER;
let INK;
let KEYS = 7;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0, 0, 0);
	INK = color(250, 250, 250);
	noLoop();
}

function draw() {
  	background(PAPER);
  	
	let S =  float(min(width, height));
	let U = 0.002;
	let keyWidth = float(1.0 / (KEYS+2));
	let keyHeight = float(3.8 * keyWidth);
	
	translate(0.50*width, 0.25*height);
	scale(S);
	strokeWeight(2*U);
	fill(INK);
	
	for(let i=0; i<KEYS; i++) {
		rect(0+(i-KEYS/2.0)*keyWidth, 0, keyWidth, keyHeight);
	}

	fill(PAPER);
	for(i=0; i<KEYS-1; i++) {
		if (i != 2) {
			rect((0.25*keyWidth)+(i-(KEYS-1)/2.0)*keyWidth, 0, 0.50*keyWidth, 0.65*keyHeight);
		}
	}
}

function keyTypes(){
	if (key=='s'){save("the-pianist.png")}
}