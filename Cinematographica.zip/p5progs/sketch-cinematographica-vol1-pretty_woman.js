// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/pretty_woman
// Date: 2016
// Description: Pretty Woman (1990)

let INK1;
let INK2;
let INK3;
let INK4;

function setup() {
	createCanvas(480, 640);
	INK1 = color(240);
	INK2 = color(55, 100, 165);
	INK3 = color(250, 225, 205);
	INK4 = color(135);
	noLoop();
}

function draw() {

	translate(width/2.0, height/2.0);
	noStroke();
	fill(INK1);
	rect(-width/2.0, -height/2.0, width, height/2.0);

	fill(INK2);
	rect(-width/2.0, 0, width, height/2.0);

	fill(INK3);
	stroke(0x22FFFFFF & INK4);
	strokeWeight(3.0);
	ellipse(-0.6*width, 0, 1.0*width,  1.25*width);
	ellipse( 0.6*width, 0, 1.0*width,  1.25*width);

	stroke(INK4);
	strokeWeight(8.0);
	ellipse(0, 0, 0.3*width,  0.3*width);
  
}
function keyTypes(){
	if (key=='s'){save('pretty-woman.png')}
}