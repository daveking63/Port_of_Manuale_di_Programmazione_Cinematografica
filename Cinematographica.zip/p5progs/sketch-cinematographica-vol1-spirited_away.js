// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/spirited_away
// Date: 2016
// Description: Spirited away (2001)

let PAPER;
let INK1;
let INK2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(20);
	INK1 = color(205, 195, 180);
	INK2 = color(145, 35, 35);
	noLoop();
}

function draw() {
    background(PAPER);
    
  let d = float(min(width, height) / 1.5);
  
  translate(width/2.0, height/2.0);
  noStroke();
  fill(INK1);
  ellipse(0, 0, d, 1.3*d);
  
  fill(INK2);
  ellipse(0, 0, 0.7*d, 1.1*d);
  
  rectMode(CENTER);
  fill(INK1);
  rect(0, 0, 0.4*d, 1.1*d);
  rect(0, -0.1*d, 0.9*d, 0.25*d);
  
  fill(0x44000000 | (PAPER & 0x00FFFFFF));
  rect(width/4.0, 0, width/2.0, height);
  
  fill(PAPER);
  rect(0, 0.5*d, 0.25*d, 0.09*d, d);
  
  ellipse(-0.26*d, -0.1*d, 0.2*d, 0.1*d);
  ellipse( 0.26*d, -0.1*d, 0.2*d, 0.1*d);
  
}

function keyTypes(){
	if (key=='s'){save("spirited-away.png")}
}