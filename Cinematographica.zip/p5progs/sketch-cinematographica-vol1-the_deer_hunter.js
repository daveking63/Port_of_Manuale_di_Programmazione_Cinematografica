// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/deer_hunter_the
// Date: 2016
// Description: The Deer Hunter (1978)

let PAPER;
let INK;
let BULLETS = 6;

function setup() {
	createCanvas(480, 640);
	PAPER = color(195, 180, 130);
	INK = color(135, 45, 25);
	BULLETS = 6;
	noLoop();
}

function draw() {
	background(PAPER);

	let dA = float(TWO_PI/BULLETS);
	let cX = float(min(width, height) / 4);
	let cY = float(0.0);
	let s = float(cX / 1.2);

	translate(width/2.0, height/2.0);
	noFill();
	stroke(INK);
	strokeWeight(0.04*s);

	for (let i=0; i<BULLETS; i++) {
		ellipse(cX, cY, s, s);
		rotate(dA);
	}

	rotate(-dA);

	noStroke();
	fill(INK);
	ellipse(cX, cY, 0.85*s, 0.85*s);

	stroke(PAPER);
	point(cX, cY);
}

function keyTypes(){
	if (key=='s'){save("the-deer-hunter.png")}
}