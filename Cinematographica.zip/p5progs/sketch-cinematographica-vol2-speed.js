// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/speed
// Date: 2015
// Description: Speed (1994)

let PAPER;
let INK1;
let INK2;
let NOTCHES = 16;
let TAILS;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0);
	INK1 = color(255);
	INK2 = color(255, 0, 0);
    TAILS = PI/8.0;
	noLoop();
}


function draw() {

	background(PAPER);

	strokeWeight(5);
	translate(width/2.0, height/2.0);
	rotate(TAILS);

	for (let i=0; i<=NOTCHES; i++) {
		stroke((i<NOTCHES/5) ? INK2 : INK1);
		line(80 + (i%2)*10, 0, 100, 0);
		rotate(-(PI+2*TAILS)/NOTCHES);
	}

	line(0, 0, -80, -20);

}

function keyTypes(){
	if (key=='s'){save("speed.png")}
}