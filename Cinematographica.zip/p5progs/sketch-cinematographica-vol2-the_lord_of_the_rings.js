// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/lord_of_the_rings_the
// Date: 2015
// Description: The Lord of the Rings (1978)

let PAPER;
let INK;
let  SIZE = 0.625;

function setup() {
	createCanvas(480, 640);
	PAPER = color(45, 60, 40);
	INK = color(245, 220, 0);
	noLoop();
}

function draw() {
	background(PAPER);

	translate(0.5*width, 0.5*height);
	scale(min(width, height));
	noFill();
	stroke(INK);
	strokeWeight(0.15*SIZE);

	ellipseMode(CENTER);
	ellipse(0, 0, SIZE, SIZE);
}

function keyTypes(){
	if (key=='s'){save("the-lord-of-the-rings.png")}
}