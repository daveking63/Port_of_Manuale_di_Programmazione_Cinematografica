// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/tonari_no_totoro
// Date: 2017
// Description: Tonari no Totoro (1988)

// Animation, Family, Fantasy
// http://www.imdb.com/title/tt0096283/

let PAPER;
let INK1;
let INK2;
let INK3;

function setup() {
	createCanvas(480, 640);
	PAPER = color(90, 85, 80);
	INK1 = color(240);
	INK2 = color(30);
	INK3 = color(230, 210, 170);
	noLoop();
}

function draw() {
	background(PAPER);
	let S = float(min(width, height));
	let U = 0.002;

	translate(0.50*width, 0.25*height);
	scale(S);
	noStroke();
	fill(INK1);
	ellipse(-0.30, 0.0, 0.2, 0.2);
	ellipse( 0.30, 0.0, 0.2, 0.2);

	fill(INK2);
	ellipse(-0.25, 0.0, 0.1, 0.1);
	ellipse( 0.25, 0.0, 0.1, 0.1);

	ellipse(0.0, 0.05, 0.1, 0.02);
	ellipse(0.0, 0.06, 0.03, 0.02);

	fill(INK3);
	ellipse(0.0, 1.0, 1.5, 1.5);

	fill(PAPER);
	ellipse( 0.0, 0.45, 0.2, 0.2);
	fill(INK3);
	ellipse( 0.0, 0.48, 0.3, 0.2);

	fill(PAPER);
	ellipse(-0.2, 0.55, 0.2, 0.2);
	ellipse( 0.2, 0.55, 0.2, 0.2);
	fill(INK3);
	ellipse(-0.2, 0.58, 0.3, 0.2);
	ellipse( 0.2, 0.58, 0.3, 0.2);
}

function keyTypes(){
	if (key=='s'){save("tonari-no-totoro.png")}
}  