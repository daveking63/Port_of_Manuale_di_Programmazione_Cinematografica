// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/coraline
// Date: 2016
// Description: Coraline (2009)

let PAPER;
let INK1;
let INK2;
let INK3;

function setup() {
	createCanvas(480, 640);
	PAPER = color(100, 145, 140);
	INK1 = color(130, 90, 50);
	INK2 = color(90, 65, 25);
	INK3 = color(30, 30, 30);
	noLoop();
}

function draw() {
	background(PAPER);

	let s = float(min(width, height) / 4.8);

	translate(width/2.0, height/3.0);
	drawButton(-s, 0, s);
	drawButton( s, 0, s);
  
}

function keyTypes(){
	if (key=='s'){save('("coraline.png")')}
}

function drawButton(x, y, s) {
  
	push();
		translate(x, y);

		let l0 = float(0.07*s);
		let l1 = float(0.11*s);
		let l2 = float(0.16*s);

		fill(INK1);
		stroke(INK2);
		strokeWeight(l0);

		ellipseMode(CENTER);
		ellipse(0, 0, s, s);

		fill(INK3);
		noStroke();
		rotate(-PI/3.0);

		ellipse(-l1, -l1, l2, l2);
		ellipse( l1, -l1, l2, l2);
		ellipse( l1,  l1, l2, l2);
		ellipse(-l1,  l1, l2, l2);
	pop();
}