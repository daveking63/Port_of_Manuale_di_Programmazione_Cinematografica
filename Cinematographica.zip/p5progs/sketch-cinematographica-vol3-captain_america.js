// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/captain_america
// Date: 2015
// Description: Captain America: the First Avenger (2011)

let PAPER;
let INK1;
let INK2;
let INK3;

function setup() {
	createCanvas(480, 640);
	PAPER = color(235, 225, 205);
	INK1 = color(215, 50, 40);
	INK2 = color(240, 245, 245);
	INK3 = color(0, 140, 165);
	noLoop();
}

function draw() {
	background(PAPER);

	translate(width/2.0, height/2.0);
	stroke(INK1);  
	strokeWeight(35.0);

	fill(INK2);
	ellipse(0, 0, 340, 340);

	fill(INK3);
	ellipse(0, 0, 200, 200);

	noStroke();
	fill(INK2);

	beginShape();
		vertex(  0, -50); 
		vertex( 29,  40);
		vertex(-47, -15); 
		vertex( 47, -15);
		vertex(-29,  40);
	endShape(CLOSE);
}

function keyTypes(){
	if (key=='s'){save("captain-america.png")}
} 