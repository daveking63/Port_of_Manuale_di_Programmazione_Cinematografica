// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/thin_red_line_the
// Date: 2015
// Description: The thin red line (1998)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(240, 240, 240);
	INK = color(190, 0, 50);
	noLoop();
}

function draw() {
	background(PAPER);
	stroke(INK);
	line(0, height/2.0, width, height/2.0);
}
 
 function keyTypes(){
	if (key=='s'){save("the-thin-red-line.png")}
}