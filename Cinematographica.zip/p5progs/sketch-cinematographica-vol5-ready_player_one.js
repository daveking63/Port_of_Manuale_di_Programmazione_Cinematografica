// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/ready_player_one
// Date: 2019
// Description: Ready Player One (2018)

let PAPER, INK1, INK2, INK3;

function setup() {
  createCanvas(480, 640);
  PAPER = color(35, 40, 50);
  INK1 = color(220, 115, 55);
  INK2 = color(45, 150, 75);
  INK3 = color(170, 175, 200);
  noLoop();
}


function draw() {
  
  let S =  float(min(width, height));
  let U = 0.002;
  
  translate(0.4*width, 0.05*height);
  scale(S);
  
  background(PAPER);
  
  strokeWeight(20*U);
  fill(PAPER);
  
  translate(0.0, 0.3);
  stroke(INK1);
  drawKey();

  translate(0.0, 0.3);
  stroke(INK2);
  drawKey();

  translate(0.0, 0.3);
  stroke(INK3);
  drawKey();
}


function drawKey() {
  
  strokeCap(SQUARE);
  rectMode(CENTER);
  
  line(0.00, 0.00, 0.30, 0.00);
  line(0.26, 0.04, 0.30, 0.04);
  line(0.18, 0.04, 0.22, 0.04);
  
  rect(0.00, 0.00, 0.10, 0.10);
}

function keyTypes(){
if (key=='s'){save('ready_player_one.png')}
}