// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/frozen
// Date: 2016
// Description: Frozen (2013)

let PAPER;
let INK;
let COUNT = 8;

function setup() {
	createCanvas(480, 640);
	PAPER = color(85, 115, 200);
	INK = color(240, 240, 240);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let s = float(min(width, height) / 48.0); 

	translate(width/2.0, height/2.0);
	stroke(INK);
	strokeWeight(s);

	for (let i=0; i<COUNT; i++) {
		line(0, 0, 0.4*width, 0);
			for (let k=0; k<5; k++) {
			  let step = float(0.07*k*width);
			  line(step, 0, step+2*s, 2*s);
			  line(step, 0, step+2*s, -2*s);
			}
		rotate(TWO_PI / COUNT);
	}
}

function keyTypes(){
	if (key=='s'){save("frozen.png")}
}