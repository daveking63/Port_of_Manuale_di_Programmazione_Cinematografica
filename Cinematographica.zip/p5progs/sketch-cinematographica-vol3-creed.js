// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/creed
// Date: 2016
// Description: Creed (2015)

let PAPER;
let INK1;
let INK2;
let STRIPES = 5;

function setup() {
	createCanvas(480, 640);
	PAPER = color(20, 35, 85);
	INK1 = color(225, 0, 20);
	INK2 = color(255);
	noLoop();
}

function draw() {
	background(PAPER);

	let deltaX = float(width/STRIPES);
	let deltaY = float(height/4.0);

	noStroke();
	fill(INK2);

	for (let i=0; i<STRIPES; i++) {
		star((0.5+i)*deltaX, deltaY/2.0, 0.6);
	}

	translate(0, deltaY);
	fill(INK2);
	
	for (let i=0; i<STRIPES; i++) {
		fill(i%2==0 ? INK1 : INK2);
		rect(i*deltaX, 0, deltaX, 3*deltaY);
	} 
}


function star(x, y, createcanvas) {
	push();
		translate(x, y);
		scale(createcanvas, createcanvas);
		beginShape();
			vertex(0, -50);
			vertex(29, 40);
			vertex(-47, -15);
			vertex(47, -15);
			vertex(-29, 40);
		endShape(CLOSE);
	pop();
}

function keyTypes(){
if (key=='s'){save("creed.png")}
}