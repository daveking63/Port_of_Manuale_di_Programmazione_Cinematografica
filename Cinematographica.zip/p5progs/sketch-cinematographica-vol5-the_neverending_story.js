// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/neverending_story_the
// Date: 2018
// Description: The Neverending Story (1984)

let PAPER;
let INK1;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0);
	INK1 = color(250, 215, 75);
	noLoop();
}

function draw() {
	background(PAPER);
		
	let S = float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.5*height);
	scale(S);
	fill(INK1);
	noStroke();

	let x;
	let y;

	for (let a=0.0; a<=2*TWO_PI; a+=0.01) {
		if (a<TWO_PI) {
			x = 0.4*cos(a);
			y = 0.4*sin(a);
		} else {
			x = 0.4*cos(a);
			y = 0.35*sin(a)*cos(a);
		}
		ellipse(x, y, 0.06, 0.06);
	}

	ellipse(0.0, -0.4, 0.2, 0.1);
	ellipse(0.0,  0.4, 0.2, 0.1);
}

function keyTypes(){
	if (key=='s'){save("the-neverending-story.png")}
}  