// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/petit_prince_le
// Date: 2015
// Description: Le Petit Prince (2015)

// Animation, Adventure, Drama
// http://www.imdb.com/title/tt1754656/

let PAPER;
let INK1;
let INK2;
let INK3;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255, 230, 100);
	INK1 = color(35);
	INK2 = color(220, 80, 30);
	INK3 = color(100, 145, 140);
	noLoop();
}

function draw() {
	background(PAPER);
	let S = float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.4*height);
	scale(S);
	fill(240);
	stroke(INK1);
	strokeWeight(8*U);

	triangle(-0.05, 0.02, -0.28, -0.4, -0.22, 0.03);
	triangle( 0.05, 0.02,  0.28, -0.4,  0.22, 0.03);

	fill(INK2);
	noStroke();

	beginShape();
	vertex(-0.15, -0.10);
	vertex( 0.15, -0.10);
	vertex( 0.25,  0.00);
	vertex( 0.00,  0.40);
	vertex(-0.25,  0.00);
	endShape(CLOSE);

	fill(INK1);
	triangle(0.00, 0.40, -0.035, 0.35, 0.035, 0.35);

	drawButton(-0.1, 0.02, 0.1, INK3, INK1);
	drawButton( 0.1, 0.02, 0.1, INK3, INK1);
}

function drawButton(x, y, s, c1, c2) {
  
  	push();
		translate(x, y);
		let l0 = 0.07*s;
		let l1 = 0.11*s;
		let l2 = 0.16*s;
		fill(c1);
		stroke(c2);
		strokeWeight(l0);
		ellipseMode(CENTER);
		ellipse(0, 0, s, s);
		fill(c2);
		noStroke();
		rotate(-PI/3.0);
		ellipse(-l1, -l1, l2, l2);
		ellipse( l1, -l1, l2, l2);
		ellipse( l1,  l1, l2, l2);
		ellipse(-l1,  l1, l2, l2);
	pop();
}

function keyTypes(){
	if (key=='s'){save("le-petit-prince.png")}
}  