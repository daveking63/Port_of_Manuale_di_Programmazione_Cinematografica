// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/iron_man
// Date: 2016
// Description: Iron Man (2008)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(180, 5, 30);
	INK = color(255, 235, 0);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let s = float(min(width, height));
	translate(width/2.0, height/2.0);
	scale(s / 480, (-1.33*s) / 640);
	noStroke();

	ellipseMode(CENTER);

	fill(INK);
	ellipse(0, 0, 220, 220);

	fill(PAPER);
	ellipse(0, 0, 160, 160);

	rotate(TWO_PI/16);
	fill(PAPER);
	for (let i=0; i<8; i++) {
		rotate(TWO_PI/8);
		quad(0, 0, 220, 45, 220, -45, 0, 0);
	}

	fill(INK);
	ellipse(0, 0, 100, 100);
  
}
function keyTypes(){
	if (key=='s'){save('iron-man.png')}
}