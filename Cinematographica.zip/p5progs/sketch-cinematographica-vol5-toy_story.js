// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/toy_story
// Date: 2019
// Description: Toy Story (1995)

let PAPER, INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(125, 155, 185);
	INK = color(255);
	noLoop();
}

function draw() {

	let S =  float(min(width, height));
	let U = 0.002;

	randomSeed(0);

	translate(0.5*width, 0.5*height);
	scale(S);

	background(PAPER);

	strokeCap(ROUND);
	strokeWeight(8*U);

	drawCloud(-0.2, -0.4, 1.0);
	drawCloud(-0.3, -0.2, 0.8);
	drawCloud( 0.2, -0.1, 1.5);
	drawCloud(-0.1,  0.1, 1.0);
	drawCloud( 0.3,  0.3, 1.2);
	drawCloud(-0.2,  0.5, 1.0);
}

function drawCloud(x, y, s) {
	push();
		translate(x, y);
		scale(s);

		stroke(INK);
		line(-0.12, 0.00, 0.10, 0.00);

		fill(INK);
		noStroke();
		ellipse(-0.02, -0.027, 0.13, 0.07);
		ellipse( 0.05, -0.040, 0.09, 0.08);
		ellipse( 0.00, -0.070, 0.10, 0.12);
	pop();
}

function keyTypes(){
if (key=='s'){save('toy_story.png')}
}