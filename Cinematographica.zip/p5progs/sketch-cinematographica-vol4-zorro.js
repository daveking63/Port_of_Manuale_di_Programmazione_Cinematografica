// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/zorro
// Date: 2016
// Description: Zorro (1975)

let PAPER;
let INK;

function setup() { 
	createCanvas(480, 640);
	PAPER = color(35);
	INK = color(240);
	noLoop();
}

function draw() {
	background(PAPER);

	randomSeed(100);

	let s = float(0.3 * min(width, height));
	let w = float(0.03 * s);

	translate(width/2.0, height/2.0);
	stroke(INK);

	handDraw(-s,     -s,  s,     -s, w);
	handDraw( s,     -s, -s,  0.8*s, w);
	handDraw(-s,  0.8*s,  s,  0.8*s, w);
}

function handDraw (x1, y1, x2, y2, w) {
	strokeWeight(w);
	for (let i=0; i<w*4; i++) {
		let d1 = float((0.8*w)*randomGaussian());
		let d2 = float((0.8*w)*randomGaussian());
		let d3 = float((0.8*w)*randomGaussian());
		let d4 = float((0.8*w)*randomGaussian());
		line(x1+d1, y1+d2, x2+d3, y2+d4);
	} 
}

function keyTypes(){
	if (key=='s'){save("zorro.png")}
}  