// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/modern_times
// Date: 2015
// Description: Modern Times (1936)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(240);
	INK = color(45, 60, 40);
	noLoop();
}

function draw() {
	background(PAPER);

	translate(width/2.0, height/3.0);

	drawGear(0, 0, 75, 20, 0);
	drawGear(99, 98, 50, 20, 2);
	drawGear(21, 178, 50, 20, 0);
	drawGear(70, 262, 35, 20, 0);
}

function drawGear(x, y, r, s, a) {
	push();
		fill(INK);
		noStroke();

		translate(x, y);
		rotate(a);

		rectMode(CENTER);
		ellipseMode(CENTER);

		let n = int((r*PI) / s);

		for (let i=0; i<n; i++) {
			rect(r, 0, s, s);
			rotate(TWO_PI / n);
		}
		
		ellipse(0, 0, 2*r, 2*r);

		fill(PAPER);
		ellipse(0, 0, 5, 5); 
	pop();
}

function keyTypes(){
	if (key=='s'){save("modern-times.png")}
}
