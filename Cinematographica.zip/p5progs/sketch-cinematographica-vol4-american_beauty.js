// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/american_beauty
// Date: 2017
// Description: American Beauty (1999)

let PAPER;
let INK1;
let INK2;
let S = 0.1;
let U = 0.02;

function setup() {
  
	createCanvas(480, 640);
	PAPER = color(240, 195, 160);
	INK1 = color(100, 155, 50);
	INK2 = color(150, 50, 35);
	noLoop();
}

function draw() {
	background(PAPER);

	let F = float(S*min(width, height));

	translate(0.6*width, 0.6*height);
	scale(F);
	rotate(0.15*PI);
	stroke(INK1);
	strokeWeight(5*U);
	line(0, -1, 0, 5);

	fill(INK1);
	noStroke();
	quad(0, 0, -1, -0.5, -1.5, -0.1, -0.7, 0.1);

	fill(INK2);
	noStroke();

	let a = float(0.1*PI);
	rotate(-a);
	for (let i=0; i<3; i++) {
		triangle(-0.8, -2, 0.8, -2, 0, 0);
		rotate(a);
	}
}

function keyTypes(){
	if (key=='s'){save("american-beauty.png")}
}