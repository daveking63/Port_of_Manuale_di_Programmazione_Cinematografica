// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/jaws
// Date: 2015
// Description: Jaws (1975)

let PAPER;
let INK;
let TEETH = 10.0;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0, 105, 165);
	INK = color(195, 180, 130);
	noLoop();
}

function draw() {
	background(PAPER);
	
	fill(INK);
	noStroke();
	scale(width/TEETH, height/TEETH);
	drawTeeth();

	resetMatrix();
	translate(0, height);
	scale(width/TEETH, -height/TEETH);
	drawTeeth();
}

function drawTeeth() {
	rect(0, 0, width/TEETH, 1);
	for(let i=0; i<TEETH; i++) {
		triangle(i, 1, i+1, 1, i+0.5, 2);
	}
}

function keyTypes(){
	if (key=='s'){save("jaws.png")}
}