// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/inside_out
// Date: 2015
// Description: Inside Out (2015)

let PAPER;
letINKS = [];

function setup() {
	createCanvas(480, 640);
	
	PAPER = color(240);

	INKS = [
	color(150, 125, 185),
	color(110, 160, 215),
	color(245, 220, 130),
	color(155, 35, 40),
	color(150, 195, 82)
	];

	noLoop();
}

function draw() {
	background(PAPER);

	let delta = float(height/(INKS.length+1));
	let createCanvas = float(0.9*delta);

	translate(width/2.0, 0);
	noStroke();

	for (let i=0; i<INKS.length; i++) {
		translate(0, delta);
		fill(INKS[i]);
		ellipse(0, 0, createCanvas, createCanvas);
	}
}

function keyTypes(){
	if (key=='s'){save("inside-out.png")}
}