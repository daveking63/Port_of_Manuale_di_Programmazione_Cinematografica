// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/reservoir_dogs
// Date: 2016
// Description: Reservoir dogs (1992)

let D1 = 120;
let D2 = 0.1*D1;
let PAPER;
let INKS = [];

function setup() {
	createCanvas(480, 640);
	PAPER = color(40, 40, 40);
	
	INKS = [
		color(30, 150, 210),
		color(110, 70, 20),
		color(230, 215, 5),
		color(245, 125, 10),
		color(245, 245, 245),
		color(200, 55, 145),
	];
	
	noLoop();
}

function draw() {
	background(PAPER);
	let count = int(INKS.length);
	let step = float(width / (count+1));

	translate((width-(count-1)*step)/2.0, height/3.0);
	noStroke();

	for (let i=0; i<count; i++) {
		fill(INKS[i]);
		quad(0, D2, D2/2, 0, 0, -D2/2, -D2/2, 0);
		quad(0, 0, D2, D1, 0, D1+D2, -D2, D1);
		translate(step, 0.0);
	}

}
function keyTypes(){
	if (key=='s'){save('reservoir-dogs.png')}
}