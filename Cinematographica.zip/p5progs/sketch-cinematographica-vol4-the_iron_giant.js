// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/iron_giant_the
// Date: 2017
// Description: The Iron Giant (1999)

let PAPER;
let INK1;
let INK2;
let L = 0.7;

function setup() {
	createCanvas(480, 640);
	PAPER = color(235, 135, 85);
	INK1 = color(60, 45, 35);
	INK2 = color(255, 255, 205);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let S =  float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.6*height);
	scale(S);
	strokeWeight(3*U);
	fill(INK1);
	noStroke();
	rectMode(CENTER);
	rect(0, 0, L, 0.6*L);
	ellipse(0, -0.3*L, L, L);

	fill(INK2);
	ellipse(-0.24*L, -0.24*L, 0.3*L, 0.3*L);
	ellipse( 0.24*L, -0.24*L, 0.3*L, 0.3*L);

	fill(INK1);
	stroke(PAPER);
	quad(0, 0, -0.1*L, -0.8*L, 0, -0.9*L, 0.1*L, -0.8*L);
}
  
function keyTypes(){
	if (key=='s'){save("the-iron-giant.png")}
}