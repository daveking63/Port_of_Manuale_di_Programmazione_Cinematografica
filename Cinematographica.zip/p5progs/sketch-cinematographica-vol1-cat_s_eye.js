// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/cat_s_eye
// Date: 2016
// Description: Stephen King's Cat's Eye (1985)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(15);
	INK = color(240, 240, 210);
	noLoop();
}

function draw() {
	background(PAPER);

	let s = float(1.35 * width);

	translate(width/2.0, height/2.0);
	noStroke();
	fill(INK);
	ellipse(0, 0, s, 0.75*s);

	fill(PAPER);
	ellipse(0, 0, 0.15*s, 0.70*s);
}

function keyTypes(){
	if (key=='s'){save("cat-s-eye.png")}
}