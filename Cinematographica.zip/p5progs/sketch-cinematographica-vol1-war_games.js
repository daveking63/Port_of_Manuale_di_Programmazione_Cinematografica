// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/war_games
// Date: 2015
// Description: Wargames (1983)

let PAPER;
let INK;

function setup() {  
	createCanvas(480, 640);
	PAPER = color(30);
	INK = color(0, 185, 85);
	noLoop();
}

function draw() {
	background(PAPER);

	scale(min(width, height)/10.0);
	stroke(INK);
	strokeCap(ROUND);
	strokeWeight(80.0/min(width, height));
	noFill();

	line(4, 2, 4, 8);
	line(6, 2, 6, 8);

	line(2, 4, 8, 4);
	line(2, 6, 8, 6);

	ellipse(3, 3, 1, 1);
	ellipse(7, 5, 1, 1);
	ellipse(5, 5, 1, 1);
	ellipse(5, 7, 1, 1);
	ellipse(7, 3, 1, 1);

	line(5, 2.5, 5, 3.5);
	line(3, 4.5, 3, 5.5);
	line(3, 6.5, 3, 7.5);
	line(7, 6.5, 7, 7.5);
}

function keyTypes(){
	if (key=='s'){save("war-games.png")}
}