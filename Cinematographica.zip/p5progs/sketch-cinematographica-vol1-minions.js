// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/minions
// Date: 2016
// Description: Minions (2015)

let PAPER;
let INK1;
let INK2;
let INK3;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255, 255, 15);
	INK1 = color(40, 40, 40);
	INK2 = color(240, 240, 240);
	INK3 = color(150, 150, 150);
	noLoop();
}

function draw() {
	background(PAPER);

	let s = float(0.4 * min(width, height));

	stroke(INK1);
	strokeWeight(0.2*s);
	line(0, height/5.0, width, height/5.0);

	fill(INK2);
	stroke(INK3);
	strokeWeight(0.125*s);
	ellipse(width/2.0, height/5.0, s, s);

	fill(INK1);
	noStroke();
	ellipse(width/2.0, height/5.0, 0.25*s, 0.25*s);

}
function keyTypes(){
	if (key=='s'){save('minions.png')}
}