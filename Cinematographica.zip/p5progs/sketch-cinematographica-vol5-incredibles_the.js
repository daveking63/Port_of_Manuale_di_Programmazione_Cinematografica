// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/incredibles_the
// Date: 2019
// Description: The Incredibles (2004)

let PAPER, INK1, INK2


function setup() {
	createCanvas(480, 640);
	PAPER = color(30, 175, 210);
	INK1 = color(0, 0, 0);
	INK2 = color(200, 30, 35);
	noLoop();
}

function draw() {
  
	let S =  float(min(width, height));
	let U = 0.002;
  
	translate(0.5*width, 0.5*height);
	scale(S);

	background(PAPER);


	fill(INK1);
	noStroke();

	ellipse(0.0, -0.6, 1.8, 0.6);

	fill(INK2);
	stroke(PAPER);
	strokeWeight(12*U);

	ellipse(0.00, -0.30, 0.35, 0.25);

	fill(INK1);
	noStroke();

	quad(-0.08, -0.15, 0.08, -0.15, 0.12, 0.40, -0.12, 0.40);
}

function keyTypes(){
	if (key=='s'){save('incredibles_the.png')}
}
