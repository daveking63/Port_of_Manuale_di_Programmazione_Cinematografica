// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/fifty_shades_of_grey
// Date: 2016
// Description: Fifty Shades of Grey (2015)

let ROWS = 10;
let COLS = 5;

function setup() {
	createCanvas(480, 640);
	noLoop();
}

function draw() {
	
	scale(width/COLS, height/ROWS)
	let dC = float(256/50.0);

	noStroke();
  
	let index = 50;
	for (let j=0; j<ROWS; j++) {
		for (let i=0; i<COLS; i++) {
			fill(index*dC);
			rect(i, j, 1, 1);
			index--;
		}
	} 
}

function keyTypes(){
	if (key=='s'){save("fifty-shades-of-grey.png")}
}
