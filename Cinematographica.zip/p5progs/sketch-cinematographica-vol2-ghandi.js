// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/gandhi
// Date: 2016
// Description: Gandhi (1982)

let PAPER;
let INK1;
let INK2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(235, 225, 160);
	INK1 = color(240);
	INK2 = color(165, 75, 30);
	noLoop();
}

function draw() {
	background(PAPER);

	let s1 = float(0.3 * min(width, height));
	let s2 = float(0.05*s1);
	let cx = float(0.7*s1);
	let bx = float(cx + 0.5*s1);

	translate(width/2.0, height/3.0);
	fill(INK1);
	stroke(INK2);
	strokeWeight(s2);

	ellipse(-cx, 0, s1, s1);
	ellipse( cx, 0, s1, s1);

	noFill();
	arc(0, 0, 0.5*s1, 4.0*s2, -PI, 0, OPEN);
	line(-bx-2*s2, 0, -bx, 0);
	line( bx+2*s2, 0,  bx, 0);

}
function keyTypes(){
	if (key=='s'){save("gandhi.png")}
}