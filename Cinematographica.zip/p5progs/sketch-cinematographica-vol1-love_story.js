// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/love_story
// Date: 2016
// Description: Love Story (1970)


let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(240);
	INK = color(190, 0, 50);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let s = float(0.35 * min(width, height));

	translate(width/2.0, height/3.0);
	fill(INK);
	noStroke();

	ellipseMode(CENTER);

	push();
		rotate(-QUARTER_PI);
		translate(-s/2.0, 0);

		ellipse(0, 0, s, s);
		rect(-s/2.0, 0, s, s);
	pop();

	rotate(QUARTER_PI);
	translate(s/2.0, 0);
	ellipse(0, 0, s, s);
}
function keyTypes(){
	if (key=='s'){save('love-story.png')}
}