// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/dune
// Date: 2016
// Description: Dune (1984)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255, 160, 10);
	INK = color(255, 205, 60);
	noLoop();
}

function draw() {
	background(PAPER);

	let s = float(0.6 * min(width, height));

	translate(width/2.0, height/2.0);
	fill(INK);
	noStroke();

	ellipse(0, 0, s, s);
	filter(BLUR, 8);
	ellipse(0, 0, s, s);
}

function keyTypes(){
	if (key=='s'){save("dune.png")}
}