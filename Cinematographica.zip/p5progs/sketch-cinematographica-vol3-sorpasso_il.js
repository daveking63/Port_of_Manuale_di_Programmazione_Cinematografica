// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/sorpasso_il
// Date: 2015
// Description: Il Sorpasso (1962)

let PAPER;
let INK1;
let INK2;
let STROKE = 20.0;

function setup() {
	createCanvas(480, 640);
	PAPER = color(240);
	INK1 = color(0, 105, 165);
	INK2 = color(190, 0, 50);
	noLoop();
}

function draw() {
	background(PAPER);

	strokeWeight(STROKE);
	strokeJoin(ROUND);
	strokeCap(ROUND);
	noFill();
	stroke(INK1);
	
	line(300, 400, 300, 250);
	line(300, 250, 300-STROKE, 250+STROKE);
	line(300, 250, 300+STROKE, 250+STROKE);

	stroke(INK2);
	beginShape();
		vertex(300, 550); vertex(300, 450);
		vertex(250, 400); vertex(250, 250);
		vertex(250, 250); vertex(300, 200);
		vertex(300, 100);
		endShape();
	line(300, 100, 300-STROKE, 100+STROKE);
	line(300, 100, 300+STROKE, 100+STROKE);
}
 
function keyTypes(){
	if (key=='s'){save("il-sorpasso.png")}
}
