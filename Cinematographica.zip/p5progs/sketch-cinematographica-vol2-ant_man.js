// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/ant_man
// Date: 2016
// Description: Ant-Man (2015)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(240);
	INK = color (0);
	noLoop();
}


function draw() {
	background(PAPER);

	let s = float(min(width, height) / 240.0);

	translate(width/2.0, height/1.5);
	scale(s);
	stroke(INK);

	line( 0, 0,  0, 2);
	line(-1, 1,  1, 1);
	line(-1, 3, -1, 3);
	line( 1, 3,  1, 3);

	filter(BLUR, s/2.0);
}

function keyTypes(){
	if (key=='s'){save("ant-man.png")}
}