// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/gattaca
// Date: 2015
// Description: Gattaca (1997)

let PAPER = color(110, 70, 75);
let INK = color(240);
let LETTERS = "GCTA";
let FONT_SIZE = 32;
let f;

function preload(){
	f = loadFont('data/FiraMono-Regular.otf');
}

function setup() {
	createCanvas(480, 640);
	PAPER = color(110, 70, 75);
	INK = color(240);
	noLoop();
}

function draw() {

	background(PAPER);
	fill(INK);

	textFont(f); 
	textSize(FONT_SIZE); 
	textAlign(CENTER, CENTER);

	for (let i=0; i<width/FONT_SIZE; i++) {
		for (let j=0; j<height/FONT_SIZE; j++) {
			text(
			LETTERS.charAt(int(random(LETTERS.length()))), 
			FONT_SIZE/2.0 + FONT_SIZE*i, 
			FONT_SIZE/2.0 + FONT_SIZE*j);
		}
	}
}

function keyTypes(){
	if (key=='s'){save("gattaca.png")}
}