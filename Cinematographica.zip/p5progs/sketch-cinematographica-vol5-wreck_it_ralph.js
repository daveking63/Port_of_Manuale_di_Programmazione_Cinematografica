// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/wreck_it_ralph
// Date: 2019
// Description: Wreck-It Ralph (2012)

let PAPER, INK1, INK2, INK3;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0);
	INK1 = color(255, 220, 25);
	INK2 = color(250, 180, 55);
	INK3 = color(20, 115, 180);
	noLoop();
	}

function draw() {
  
	let S = float(min(width, height));
	let U = 0.002;

	randomSeed(0);

	translate(0.5*width, 0.6*height);
	scale(S);

	background(PAPER);

	fill(INK2);
	stroke(INK1);
	strokeWeight(20*U);

	ellipse(0.0 ,0.0, 0.4, 0.4);

	noStroke();
	fill(INK1);
	drawStar(0.00, 0.00, 0.20, 0.08);

	rectMode(CENTER);
	rect(0.0, -0.2, 0.2, 0.05);

	fill(INK3);
	rectMode(CORNERS);
	rect(-0.09, -0.7, 0.09, -0.2);
}

function drawStar(x, y, r1, r2) {
	let angle = float(TWO_PI / 5);
	let halfAngle = float(angle/2.0);
	beginShape();
		for (let a = 0.5*halfAngle; a < TWO_PI; a += angle) {
			let sx = float(x + cos(a) * r2);
			let sy = float(y + sin(a) * r2);
			vertex(sx, sy);
			sx = x + cos(a+halfAngle) * r1;
			sy = y + sin(a+halfAngle) * r1;
			vertex(sx, sy);
		}
	endShape(CLOSE);
}

function keyTypes(){
if (key=='s'){save('wreck_it_ralph.png')}
}