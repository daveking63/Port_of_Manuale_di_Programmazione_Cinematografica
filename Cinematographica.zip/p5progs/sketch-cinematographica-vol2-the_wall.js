// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/wall_the
// Date: 2015
// Description: The Wall (1982)

let PAPER;
let INK;
let W = 80;
let H = W/2;
let R = W/10;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255);	
	INK = color(32);
	noLoop();
}

function draw() {
	background(INK);
	
	stroke(INK);
	fill(PAPER);

	for (let j=0; j<height/H; j++) {
		for (let i=0; i<width/W+1; i++) {
			rect(-(W/2)*(j%2)+i*W, j*H, W, H, R);
		}
	}
}

function keyTypes(){
	if (key=='s'){save("the-wall.png")}
}