// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/bee_movie
// Date: 2016
// Description: Bee Movie (2007)

let PAPER;
let INK;
let STRIPES = 3;

function setup() {
	createCanvas(480, 640);
	PAPER = color(70, 25, 20);
	INK = color(250, 220, 55);
	noLoop();
}

function draw() {
	background(PAPER);

	let dH = float(height / (2*STRIPES));

	fill(INK);
	noStroke();

	for (let i=0; i<STRIPES; i++) {
		rect(0, 0, width, dH);
		translate(0, 2*dH);
	}
}

function keyTypes(){
	if (key=='s'){save("bee-movie.png")}
}