// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/entrapment
// Date: 2016
// Description: Entrapment (1999)


let PAPER;
let INK;
let COUNT = 6;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0);
	INK = color(240, 30, 30);
	noLoop();
}

function draw() {
	background(PAPER);
	randomSeed(100);

	let s = float(0.01 * min(width, height));
	let dH = float((0.5 * height) / COUNT);

	translate(0, height/2.0);
	stroke(INK);
	strokeWeight(s);

	for (let i=0; i<COUNT; i++) {
		line(0, dH*randomGaussian(), width, dH*randomGaussian());
		translate(0, dH);
	}

	filter(BLUR);
}

function keyTypes(){
	if (key=='s'){save("entrapment.png")}
}