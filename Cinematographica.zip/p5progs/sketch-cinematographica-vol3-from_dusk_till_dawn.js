// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/from_dusk_till_dawn
// Date: 2015
// Description: From Dusk till Dawn (1996)

let PAPER;
let INK1;
let INK2;
let SIZE = 200;
let RAYS = 7;
let DELTA = 2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(95, 80, 150);
	INK1 = color(225, 0, 50);
	INK2 = color(245, 225, 0);
	noLoop();
}

function draw() {
	background(PAPER);
	
	translate(width/2.0, height/2.0);
	noStroke();
	fill(INK1);
	
	arc(0, -DELTA, SIZE, SIZE, -PI, 0, OPEN);

	fill(INK2);
	arc(0, +DELTA, SIZE, SIZE, 0, +PI, OPEN);

	stroke(INK2);
	strokeWeight(SIZE / 20);

	for (let i=0; i<RAYS; i++) {
		line(0.6*SIZE, 0, 0.6*SIZE+0.25*SIZE, 0);
		rotate(PI / (RAYS-1));
	} 
}

function keyTypes(){
	if (key=='s'){save("from-dusk-till-dawn.png")}
}