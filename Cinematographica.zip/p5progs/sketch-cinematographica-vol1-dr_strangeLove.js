// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/dr_strangelove
// Date: 2016
// Description: Dr. Strangelove (1964)

let PAPER;
let INK;

let S = 0.10;

function setup() {
	createCanvas(480, 640);
	PAPER = color(240);
	INK = color(25, 25, 110);
	noLoop();
}


function draw() {

	let F = min(width, height);

	translate(0.5*width, 0.5*height);
	scale(F);

	background(PAPER);

	fill(INK);
	noStroke();

	rectMode(CENTER);

	rect(0, 0, 2*S, 5*S, 3*S);

	translate(0, -1.5*S);
	quad(-S, 0, S, 0, 0.5*S, -2*S, -0.5*S, -2*S);

	translate(0, -1.5*S);
	quad(0, 0, 0, -S,  S, -1.5*S,  S, -0.5*S);
	quad(0, 0, 0, -S, -S, -1.5*S, -S, -0.5*S);

}

function keyTypes(){
if (key=='s'){save('("drStrangeLove.png")')}
}