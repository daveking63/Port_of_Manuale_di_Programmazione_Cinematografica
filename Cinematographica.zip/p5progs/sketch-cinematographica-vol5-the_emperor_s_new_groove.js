// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/emperor_s_new_groove_the
// Date: 2019
// Description: The Emperor's new groove (2000)

let PAPER;
let INK1;
let INK2;
let DELTA;

function setup() {
	createCanvas(480, 640);
	PAPER = color(130, 170, 180);
	INK1 = color(250, 200, 0);
	INK2 = color(240, 160, 0);
	DELTA = 0.03*PI;
	noLoop();
}

function draw() {
	background(PAPER);
	let S =  float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.6*height);
	scale(S);
	fill(INK1);
	stroke(INK2);
	strokeWeight(3*U);
	arc(0.0, 0.0, 0.9, 0.9, -PI+DELTA, 0.0-DELTA, PIE);

	push();
	  for(let i=1; i<6; i++) {
	    rotate(-PI/6);
	    line (0.0, 0.0, 0.45, 0.0);
	  }
	pop();

	arc(0.0, 0.05, 0.4, 0.4, -PI, 0.0, CHORD);
}

function keyTypes(){
	if (key=='s'){save("the-emperor's-new-groove.png")}
}  