// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/star_wars
// Date: 2016
// Description: Star Wars (1977)

let PAPER;
let INK;
let MOON = 300.0;
let HOLE = 70.0;

function setup() {
	createCanvas(480, 640);
	PAPER = color(34, 34, 34);
	INK = color(132, 132, 130);
	noLoop();
}

	function draw() {
	background(PAPER);

	translate(width/2.0, height/2.0);
	ellipseMode(CENTER);
	rectMode(CENTER);

	noStroke();
	fill(INK);
	ellipse(0, 0, MOON, MOON);

	fill(PAPER);
	rect(0, 0, MOON, MOON/60.0);
	ellipse(HOLE, -HOLE, HOLE, HOLE);
}

function keyTypes(){
	if (key=='s'){save("star-wars.png")}
}