// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/batman
// Date: 2015
// Description: Batman (1989)

// See also:
// "Batman Curve" 
// http://mathworld.wolfram.com/BatmanCurve.html

let PAPER;
let INK1;
let INK2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(245);
	INK1 = color(30);
	INK2 = color(255, 255, 0);
	noLoop();
}

function draw() {
	background(PAPER); 
	 
	translate(width/2.0, height/2.0);
	scale(25, -25);
	fill(INK2);
	stroke(INK1);
	strokeWeight(0.5);

	ellipse(0, 0, 16, 8);

	fill(INK1);
	noStroke();

	beginShape();
		for (let x=-7.0; x<=7.0; x+=0.05) {
			vertex(x, abs(x)<3 ? g(abs(x)) : f(x));
		}
		for (let x=7.0; x>=-7.0; x-=0.05) {
			vertex(x, (abs(x)<4 ? h(abs(x)) : -f(x)));
		}  
	endShape();

	beginShape();
		vertex(-1.00, 1.00); vertex(-0.75, 3.00);
		vertex(-0.50, 2.25); vertex( 0.50, 2.25);
		vertex( 0.75, 3.00); vertex( 1.00, 1.00);
	endShape();
}

function f(x) {
  return 3*sqrt(1-sq(x/7));
}

function g(x) {
  return (3-x)/2-1.35*(sqrt(3-sq(x)+2*x)-2);
}

function h(x) {
  return x*(0.5-0.09*x)-3+sqrt(1-sq((abs(x-2)-1)));
}

function keyTypes(){
	if (key=='s'){save("batman.png")}
}