// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/star_trek
// Date: 2019
// Description: Star Trek (1979)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0);
	INK = color(240);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let S =  float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.3*height);
	scale(S);
	fill(INK);
	noStroke();
	ellipse(0.0, 0.0, 0.4, 0.4);

	stroke(INK);
	strokeWeight(35*U);
	line(0.0, 0.0, 0.0, 0.4);

	strokeWeight(20*U);
	line(0.0, 0.25, -0.15, 0.4);
	line(0.0, 0.25,  0.15, 0.4);

	strokeWeight(20*U);
	line(-0.15, 0.25, -0.15, 0.6);
	line( 0.15, 0.25,  0.15, 0.6);
}

function keyTypes(){
	if (key=='s'){save("star-trek.png")}
}  