// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/wonder_woman
// Date: 2017
// Description: Wonder Woman (2017)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(170, 20, 10);
	INK = color(225, 185, 15);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let s = float(0.1 * min(width, height));

	translate(0.5*width, 0.3*height);
	noFill();
	stroke(INK);
	strokeWeight(2*s);
	strokeCap(SQUARE);
	strokeJoin(ROUND);
	beginShape();
		vertex(-width, 0);
		vertex(-3*s, 0);
		vertex(-1.3*s, 2.5*s);
	endShape();

	strokeJoin(MITER);
	beginShape();
		vertex(-3*s, 0);
		vertex(-1.3*s, 2.5*s);
		vertex( 0, -0.1*s);
		vertex( 1.3*s, 2.5*s);
		vertex( 3*s, 0);
	endShape();

	strokeJoin(ROUND);
		beginShape();
		vertex( 1.3*s, 2.5*s);
		vertex( 3*s, 0);
		vertex( width, 0);
	endShape();
}

function keyTypes(){
	if (key=='s'){save("wonder-woman.png")}
}  