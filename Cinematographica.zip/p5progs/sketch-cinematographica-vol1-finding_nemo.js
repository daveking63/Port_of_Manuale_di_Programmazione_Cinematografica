// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/finding_nemo
// Date: 2016
// Description: Finding Nemo (2003)

let PAPER;
let INK1;
let INK2;
let STROKE = 10.0;

function setup() {
	createCanvas(480, 640);
	PAPER = color(245, 130, 0);
	INK1 = color(250);
	INK2 = color(35);
	noLoop();
}

function draw() {
	background(PAPER);
	fill(INK1);
	stroke(INK2);
	strokeWeight(STROKE);

	let dx = float(width/3.0);
	let dy = float(height/3.0);

	beginShape();
		curveVertex(0, dy+150);
		curveVertex(0, dy);
		curveVertex(dx, dy+20);
		curveVertex(2*dx, dy-15);
		curveVertex(width+STROKE, dy);
		curveVertex(width+STROKE, dy-200);
		curveVertex(width+STROKE, 2*dy);
		curveVertex(width+STROKE, 2*dy);
		curveVertex(2*dx, 2*dy+5);
		curveVertex(dx, 2*dy+50);
		curveVertex(0, 2*dy);
		curveVertex(0, 2*dy+50);
	endShape();

}
function keyTypes(){
	if (key=='s'){save('("finding-nemo.png")')}
}