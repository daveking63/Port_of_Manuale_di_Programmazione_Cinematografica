// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/chicken_run
// Date: 2016
// Description: Chicken run (2000)

let PAPER;
let INK;
let STEPS = 15;

function setup() {
	createCanvas(480, 640);
	PAPER = color(240);
	INK = color(230, 140, 35);
	noLoop();
}


function draw() {
	background(PAPER);

	randomSeed(10);
	let d = float(min(width, height))/float(STEPS);

	translate(width/2.0, 1.5*d);
	stroke(INK);
	strokeWeight(0.16*d);

	for (let i=0; i<0.8*STEPS; i++) {
		drawFootprint(0, 0, d);
		drawFootprint(2.0*d, 0.3*d, d);
		translate(random(-d, d), 2.5*d);
	}
}

function drawFootprint(x, y, s) {
	push();
		translate(x, y);
		//rotate(0.01*PI);
		line(     0, -s, 0, 0.3*s);
		line(-0.5*s, -s, 0,     0);
		line( 0.5*s, -s, 0,      0);
	pop();
}

function keyTypes(){
	if (key=='s'){save("chicken-run.png")}
}