// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/psycho
// Date: 2017
// Description: Psycho (1960)

let PAPER;
let INK1;
let INK2;
let INK3;
let U = 0.002;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255);
	INK1 = color(65, 165, 225);
	INK2 = color(140, 10, 10);
	INK3 = color(100, 100, 100);
	noLoop();
}

function draw() {
	background(PAPER);
	let F = float(min(width, height));

	translate(0.5*width, 0.5*height);
	scale(F);
	strokeWeight(10*U);
	stroke(INK1);
	
	for (let i=-0.3; i<=0.3; i+=0.1) {
		line(i, -1, i, 1);
	}

	stroke(INK2);
	for (i=0.1; i<=0.3; i+=0.1) {
		line(i, -i*0.5, i, 1);
	}

	fill(INK3);
	noStroke();
	triangle(0.02, 0, 0.5, -0.4, 0.5, -0.15);
}

function keyTypes(){
	if (key=='s'){save("psycho.png")}
}  