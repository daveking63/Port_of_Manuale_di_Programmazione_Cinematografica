// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/monsters_inc
// Date: 2015
// Description: Monsters, Inc (2001)

let PAPER;
let INK1;
let INK2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(90, 200, 200);
	INK1 = color(240);
	INK2 = color(30);
	noLoop();
}

function draw() {
	background(PAPER);

	let size = float(min(width, height) * 0.17);
	translate(width/2.0, height/3.0);
	noStroke();
	fill(INK1);
	
	arc(0,  0.30*size, 3.6*size, 1.8*size, PI+PI/10.0, TWO_PI-PI/10.0, CHORD);
	arc(0, -0.27*size, 3.6*size, 1.8*size,    PI/10.0,     PI-PI/10.0, CHORD);

	fill(INK2);
	ellipse(0, 0, size, size);
}

function keyTypes(){
	if (key=='s'){save("monsters-inc.png")}
}