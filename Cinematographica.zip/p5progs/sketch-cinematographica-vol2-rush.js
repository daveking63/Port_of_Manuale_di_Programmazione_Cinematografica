// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/rush
// Date: 2015
// Description: Rush (2013)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(244);
	INK = color(227, 0, 30);
	noLoop();
}

function draw() {

	background(PAPER);

	fill(INK);
	noStroke();

	beginShape();
		vertex(0, 0);
		vertex(width, 0);
		vertex(width, 2*height/3.0);
		vertex(width/2.0, height/2.0);
		vertex(0, 2*height/3.0);
	endShape();
  
}

function keyTypes(){
	if (key=='s'){save("rush.png")}
}