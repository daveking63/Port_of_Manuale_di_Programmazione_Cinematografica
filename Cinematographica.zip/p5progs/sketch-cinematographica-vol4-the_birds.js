// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/birds_the
// Date: 2016
// Description: The birds (1963)

let PAPER;
let INK;
let COUNT = 150;
let DELTA = 0.8;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255);
	INK = color(30);
	noLoop();
}

function draw() {
	background(PAPER);
	
	randomSeed(100);
	let s = float(min(width, height) / 4.8);

	noFill();
	stroke(INK);
	strokeWeight(0.05*s);

	for (let i=0; i<COUNT; i++) {
		resetMatrix();
		translate(random(width), random(height));
		scale(1 / (random(10)+1));
		rotate(-0.1*PI);
		arc(-0.4*s, 0, 0.8*s, s, -PI+DELTA, 0);
		arc( 0.4*s, 0, 0.8*s, s, -PI, -DELTA);
	}
}

function keyTypes(){
	if (key=='s'){save("the-birds.png")}
}