// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/memento
// Date: 2015
// Description: Memento (2000)

let PAPER;
let INK;
let SIZE = 200;

function setup() {
	createCanvas(480, 640);
	PAPER = color(30);
	INK = color(240);
	noLoop();
}

function draw() {
	background(PAPER);

	translate(width/2.0, height/2.0);
	rotate(-QUARTER_PI/2);
	fill(INK);
	rectMode(CENTER);
	rect(0, 0, SIZE, 1.2*SIZE);

	translate(0, -0.1*SIZE);
	fill(32);
	rect(0, 0, 0.9*SIZE, 0.9*SIZE);
}  
function keyTypes(){
	if (key=='s'){save("memento.png")}
}
