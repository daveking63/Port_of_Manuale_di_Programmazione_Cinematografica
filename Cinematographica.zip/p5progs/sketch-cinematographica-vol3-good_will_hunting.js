// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/good_will_hunting
// Date: 2015
// Description: Good Will Hunting (1997)

let PAPER;
let INK;
let SIZE = 5.0;

function setup() {
	createCanvas(480, 640);
	PAPER = color(60);
	INK = color(230);
	noLoop();
}

function draw() {
	background(PAPER);
	translate(width/2.0, height/2.0);
	fill(INK);
	stroke(INK);
	strokeWeight(SIZE);

	let w1 = float(width/3.0);
	let w2 = float(width/6.0);
	let h1 = float(height/5.0);
	let h2 = float(height/8.0);

	lines(-w2, 0, w2, 0, 4*SIZE);
	lines( w2, 0, w1, h2, 4*SIZE);
	lines( w2, 0, w2, h1, 4*SIZE);
}

function points(x, y, s) {
	ellipse( x,  y, s, s);
	ellipse( x, -y, s, s);
	ellipse(-x,  y, s, s);
	ellipse(-x, -y, s, s);
}

function lines(x1, y1, x2, y2, s) {
	line( x1,  y1,  x2,  y2);
	line(-x1,  y1, -x2,  y2);
	line( x1, -y1,  x2, -y2);
	line(-x1, -y1, -x2, -y2);
	points(x1, y1, s);
	points(x2, y2, s);
}

function keyTypes(){
	if (key=='s'){save("good-will-hunting.png")}
}