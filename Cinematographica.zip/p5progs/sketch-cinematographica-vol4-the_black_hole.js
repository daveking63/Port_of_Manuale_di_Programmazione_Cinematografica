// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/black_hole_the
// Date: 2017
// Description: The Black Hole (1979)
// Action, Sci-Fi
// http://www.imdb.com/title/tt0078869

let PAPER;
let INK1;
let INK2;
let INK3;

function setup() {
	createCanvas(480, 640);
	PAPER = color(115);
	INK1 = color(175, 30, 25);
	INK2 = color(240);
	INK3 = color(0);
	noLoop();
}

function draw() {
	background(PAPER);
	let S = float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.4*height);
	scale(S);
	noStroke();
	rectMode(CENTER);
	fill(INK1);
	rect(0.0, 0.0, 1.0, 0.3);

	fill(INK2);
	rect(-0.15, 0.0, 0.2, 0.2, 0.02);
	rect( 0.15, 0.0, 0.2, 0.2, 0.02);

	fill(INK3);
	ellipse(-0.15,  0.0, 0.06, 0.06);
	ellipse( 0.15, -0.0, 0.06, 0.06);
}

function keyTypes(){
	if (key=='s'){save("the-black-hole.png")}
}  