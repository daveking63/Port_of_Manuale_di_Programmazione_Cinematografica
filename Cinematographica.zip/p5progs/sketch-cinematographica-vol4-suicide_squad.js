// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/suicide_squad
// Date: 2016
// Description: Suicide Squad (2016)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(175, 20, 25);
	INK = color(0);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let s = float(0.02 * min(width, height));
	let l = 4.0*s;

	strokeWeight(s);
	stroke(INK);
	noFill();
	translate(0.33*width, 0.33*height);
	line(-l, -l, l, l);
	line(l, -l, -l, l);

	resetMatrix();
	translate(0.67*width, 0.33*height);
	line(-l, -l, l, l);
	line(l, -l, -l, l);

	resetMatrix();
	translate(0.50*width, 0.45*height);
	rotate(0.1*PI);
	line(3*l, 0, 4*l, 0);
	rotate(0.8*PI);
	line(3*l, 0, 4*l, 0);

	resetMatrix();
	translate(0.50*width, 0.45*height);
	arc(0, 0, 7*l, 7*l, 0.1*PI, 0.9*PI);
}

function keyTypes(){
	if (key=='s'){save("suicide-squad.png")}
}  