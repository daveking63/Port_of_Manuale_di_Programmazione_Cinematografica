// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/et_the_extra_terrestrial
// Date: 2016
// Description: E.T. the extra-terrestrial(1982)

let PAPER;
let INK;
let COLS = 8;

let SPRITE = 
  "XXXXXXX." +
  "X.XXXXXX" +
  "XXXXXXXX" +
  "XXXXXXXX" +
  "XX....XX" +
  "....XXXX" +
  "...XXXXX" +
  "XXXXXXXX" +
  "X.XXXXXX" +
  "..XXXXXX" +
  "..XXXXXX" +
  "..X...XX" +
  ".XX...XX" +
  "XXX..XXX";

function setup() {
	createCanvas(480, 640);
	PAPER = color(115, 145, 155);
	INK = color(125, 75, 20);
	noLoop();
}

function draw() {
	background(PAPER);
	let s = float(0.7 * (min(width, height) / (2*COLS)));
	let l = float(SPRITE.length);

	translate((width-2*s*COLS)/2.0, (height-s*l/COLS)/2.0);
	scale(2*s, s);

	fill(INK);
	noStroke();
	//stroke(PAPER);
	//strokeWeight(1.0/s);

	for (let i=0; i<l; i++) {
		if (SPRITE.charAt(i) == 'X') {
			rect(i%COLS, i/COLS, 1, 1);
		}
	}
}

function keyTypes(){
	if (key=='s'){save("et-the-extra-terrestrial.png")}
}