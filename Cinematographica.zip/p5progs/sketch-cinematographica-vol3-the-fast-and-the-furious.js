// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/fast_and_the_furious_the
// Date: 2015
// Description: The Fast and the Furious (2001)

let PAPER;
let INK;
let SIZE = 200;

function setup() {
	createCanvas(480, 640);
	PAPER = color(32);
	INK = color(242);
	noLoop();
}

function draw() {
	background(PAPER);

	let s1 = float(SIZE/40.0);
	let s2 = float(SIZE/4.0);
	let s3 = float(SIZE/8.8);

	translate(width/2.0, height/2.0);
	noFill();
	stroke(INK);
	strokeWeight(s1);

	ellipse(0, 0, SIZE, SIZE);

	line(-s2,  0,  s2,   0);
	line(  0, s3,   0, -s3);
	line(-s2, s3, -s2, -s3);
	line( s2, s3,  s2, -s3);

}

function keyTypes(){
	if (key=='s'){save("the-fast-and-the-furious.png")}
}