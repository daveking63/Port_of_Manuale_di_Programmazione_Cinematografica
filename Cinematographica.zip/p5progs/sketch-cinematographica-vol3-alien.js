// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/alien
// Date: 2015
// Description: Alien (1979)

let PAPER;
let INK;
let TEETH = 10.0;
let g;

function setup() {
	createCanvas(480, 640);
	PAPER = color(30);
	INK = color(225);
	noLoop();
}

function draw() {
	g = drawMounth();
	image(g, 0, 0);
	scale(0.25);
	image(g, 1.5*width,1.5* height);
}

function drawMounth() {
  
	let g = createGraphics(width, height);
	g.background(PAPER);
	g.fill(INK);
	g.noStroke();
    g.scale(g.width/TEETH, g.height/TEETH);
	drawTeeth(g);

	g.resetMatrix();
	g.translate(0, g.height);
	g.scale(g.width/TEETH, -g.height/TEETH);
	drawTeeth(g);

	return g;
}

function drawTeeth(g) {
	g.rect(0, 0, g.width/TEETH, 0.2);
	for(let i=0; i<TEETH; i++) {
	g.triangle(i, 0.19, i+1, 0.19, i+0.5, (i==0 || i==TEETH-1) ? 2.5 : 1);
	}
}

function keyTypes(){
	if (key=='s'){save("alien.png")}
}