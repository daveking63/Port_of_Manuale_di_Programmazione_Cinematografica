// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/one_hundred_and_one_dalmatians
// Date: 2016
// Description: One hundred and one Dalmatians (1961)

let PAPER;
let INK;
let SPOTS = 7;

function setup() {
	createCanvas(480, 640);
	PAPER = color(250);
	INK = color(35);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let s = float(0.313 * min(width, height));

	randomSeed(10);
	for (let i=0; i<SPOTS; i++) {
		drawSpot(random(width), random(height), random(s), int(0.135*s));
	}

}
function keyTypes(){
	if (key=='s'){save('one-hundred-and-one-dalmatians.png')}
}

function drawSpot(x, y, r, fuzz) {
	fill(INK);
	noStroke();

	push();
		translate(x, y);
		ellipse(0, 0, r, r);
		for (let i=0; i<fuzz; i++) {
			ellipse(random(0.2*r), random(0.2*r), r, r);
		}
	pop();
}