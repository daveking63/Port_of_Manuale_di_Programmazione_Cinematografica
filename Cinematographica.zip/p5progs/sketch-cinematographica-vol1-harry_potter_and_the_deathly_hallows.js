// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/harry_potter_and_the_deathly_hallows
// Date: 2016
// Description: Harry Potter and the deathly hallows (2010)

let PAPER;
let INK;
let RADIUS = 225;

function setup() {
	createCanvas(480, 640);
	PAPER = color(50, 55, 90);
	INK = color(215, 175, 65);
	noLoop();
}

function draw() {
	background(PAPER);

	let r = float(0.5 * min(width, height));
	let d = float(TWO_PI/3.0);

	translate(width/2.0, height/2.0);
	rotate(-HALF_PI);
	stroke(INK);
	strokeWeight(0.03*r);
	noFill();

	ellipse(0, 0, r, r);

	beginShape();
		for (let i=0; i<3; i++) {
			vertex(r*cos(i*d), r*sin(i*d));
		}
	endShape(CLOSE);

	line(-r/2, 0, +r, 0);
  
}

function keyTypes(){
	if (key=='s'){save('harry-potter-and-the-deathly-hallows.png')}
}
