// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/secretary
// Date: 2019
// Description: Secretary(2002)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(245);
	INK = color(250, 0, 0);
	noLoop();
}

function draw() {
	background(PAPER);

	let S =  float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.3*height);
	scale(-S);
	rotate(-0.1);
	noStroke();
	fill(INK);

	for (let r=0.5; r<TWO_PI+0.5; r+=0.01) {
		let a = float((r>1.5*PI) ? 0.3 : 0.4);
		let b = float(r*(0.3/TWO_PI));
		let x = float(a * cos(r));
		let y = float(b * sin(r));
		push();
			translate(x, y);
			rotate(0.5);
			ellipse(0, 0, 5*U, 10*U);
		pop();
	}
}

function keyTypes(){
	if (key=='s'){save("secretary.png")}
}  
