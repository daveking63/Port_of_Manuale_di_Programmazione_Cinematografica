// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/social_network_the
// Date: 2016
// Description: Social Network

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(60, 90, 150);
	INK = color(255);
	noLoop();
}


function draw() {
	background(PAPER);
	let s = float(0.2 * min(width, height));

	translate(width/2.0, height/4.0);
	stroke(INK);
	strokeCap(PROJECT);
	strokeJoin(ROUND);
	noFill();
	strokeWeight(s);

	beginShape();
	vertex(width/5.0, 0);
	vertex(0, 0);
	vertex(0, height/2.0); 
	endShape();

	strokeWeight(0.8*s);
	line(-width/8.0, height/4.0, width/5.0, height/4.0);
}
function keyTypes(){
	if (key=='s'){save("the-social-network.png")}
}