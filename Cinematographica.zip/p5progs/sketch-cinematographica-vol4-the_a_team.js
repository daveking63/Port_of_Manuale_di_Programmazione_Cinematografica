// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/a_team_the
// Date: 2017
// Description: The A-Team (2010)

// Action, Adventure, Comedy
// http://www.imdb.com/title/tt0429493/

let PAPER;
let INK1;
let INK2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0);
	INK1 = color(65, 65, 75);
	INK2 = color(190, 0, 0);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let S = float(min(width, height));
	let U = 0.002;

	translate(0.6*width, 0.5*height);
	scale(S);
	fill(INK1);
	noStroke();
	quad(-2.0, -1.5, 0.0, 0.0, 2.0, 0.0, -1.5, -2.0);

	fill(INK2);
	stroke(INK2);
	strokeWeight(12*U);
	line(0.0, 0.0, 2.0, 0.0);
	triangle(-2.0, -1.5, 0.0, 0.0, -2.0, -1.3);
}

function keyTypes(){
	if (key=='s'){save("the-a-team.png")}
} 