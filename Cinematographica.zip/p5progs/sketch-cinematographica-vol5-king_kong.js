// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/king_kong
// Date: 2018
// Description:  King Kong (1933)

let PAPER;
let INK1;
let INK2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(195, 190, 155);
	INK1 = color(75);
	INK2 = color(30);
	noLoop();
}

function draw() {
	background(PAPER);
	let S =  float(min(width, height));
	let U = 0.002;

	translate(0.3*width, 0.3*height);
	scale(S);
	stroke(INK1);
	strokeCap(SQUARE);
	strokeWeight(8*U);
	line(0, 0, 0, 1);

	strokeWeight(40*U);
	line(0, 0.09, 0, 1);

	strokeWeight(60*U);
	line(0, 0.12, 0, 1);

	strokeWeight(80*U);
	line(0, 0.15, 0, 1);

	strokeWeight(100*U);
	line(0, 0.18, 0, 1);

	push();
		translate(-0.085, 0.22);
		rotate(0.1*QUARTER_PI);
		drawHand();
	pop();

	translate(0.085, 0.32);
	rotate(-0.1*QUARTER_PI);
	drawHand(); 
}

function drawHand() {
	fill(INK2);
	noStroke();
	rectMode(CENTER);
	rect(0.00, 0.00, 0.07, 0.03, 0.04);
	rect(0.00, 0.03, 0.07, 0.03, 0.04);
	rect(0.00, 0.06, 0.07, 0.03, 0.04);
}

function keyTypes(){
	if (key=='s'){save("king-kong.png")}
}  