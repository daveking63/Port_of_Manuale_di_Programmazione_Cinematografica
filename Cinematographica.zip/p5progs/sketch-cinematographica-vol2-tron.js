// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/tron
// Date: 2015
// Description: Tron (1982)

let PAPER;
let INKS = [];

function setup() {
	createCanvas(480, 640);
	PAPER = color(30);
	INKS = [
		color(0, 135, 85),
		color(255, 50, 50),
		color(55, 205, 250),
	];
	noLoop();
}

function draw() {

	background(PAPER);

	noFill();
	strokeJoin(ROUND);
	strokeCap(ROUND);

	stroke(INKS[0]);
	for (let i=0; i<max(width, height); i+=80) {
		line(i, 0, i, height);
		line(0, i, width, i);
	} 

	strokeWeight(10.0);
	for (let i=1; i<INKS.length; i++) {
		stroke(INKS[i]);
		beginShape();
			vertex(2*96, 4*128); vertex(2*96, 2*128);
			vertex(3*96, 2*128); vertex(3*96, 128);
		endShape();
		translate(20, 20);
	}
  
}

function keyTypes(){
	if (key=='s'){save("tron.png")}
}