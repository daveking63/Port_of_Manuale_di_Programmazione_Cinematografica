// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/aquaman
// Date: 2018
// Description: V for Vendetta (2005)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0);
	INK = color(150, 0, 20);
	noLoop();
}

function draw() {
	background(PAPER);
	let S =  float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.5*height);
	scale(S);
	stroke(INK);
	strokeWeight(100*U);

	line(-0.6, -0.8, 0.0, 0.7);
	line( 0.6, -0.8, 0.0, 0.7);
}

function keyTypes(){
	if (key=='s'){save("v-for-vendetta.png")}
}  