// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/signs
// Date: 2017
// Description: Signs (2002)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(110, 155, 40);
	INK = color(205, 230, 150);
	noLoop();
}

function draw() {
	background(PAPER);
	let s = float(0.4 * min(width, height));

	translate(0.5*width, 0.7*height);
	noFill();
	stroke(INK);
	strokeCap(SQUARE);
	strokeWeight(0.2*s);

	ellipse(0, 0, s, s);
	arc(0, -1.5*s, 1.7*s, 1.2*s, 0, PI);
	line(0, -0.4*s, 0, -1.8*s);
	line(-0.8*s, -0.15*s, -0.8*s, 0.15*s);
	line( 0.8*s, -0.15*s,  0.8*s, 0.15*s);

	noStroke();
	fill(INK);
	ellipse(0, -1.8*s, 0.5*s, 0.5*s);
}

function keyTypes(){
	if (key=='s'){save("signs.png")}
}  