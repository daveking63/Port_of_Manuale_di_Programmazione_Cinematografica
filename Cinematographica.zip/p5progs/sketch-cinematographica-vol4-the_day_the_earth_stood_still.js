// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/day_the_earth_stood_still_the
// Date: 2016
// Description: The day the Earth stood still (1951)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(35);
	INK = color(240);
	noLoop();
}

function draw() {
	background(PAPER);
	let s = float(0.8 * min(width, height));

	translate(0.5*width, 0.3*height);
	fill(INK);
	noStroke();
	ellipse(0, 0, s, 0.15*s);
	filter(BLUR, 6);

	ellipse(0, 0, 0.3*s, 0.2*s);
	filter(BLUR, 6);
}

function keyTypes(){
	if (key=='s'){save("the-day-the-earth-stood-still.png")}
}  