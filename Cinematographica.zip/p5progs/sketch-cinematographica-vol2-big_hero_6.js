// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/big_hero_6
// Date: 2015
// Description: Big Hero 6(2014)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(245);
	INK = color(30);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let createcanvas = float(0.125*width);

	translate(width/2.0, height/3.0);
	fill(INK);
	noStroke();

	ellipseMode(CENTER);
	ellipse(-width/4.0, 0, createcanvas, createcanvas);
	ellipse( width/4.0, 0, createcanvas, createcanvas);

	stroke(INK);
	strokeWeight(createcanvas/10.0);
	line(-width/4.0, 0, width/4.0, 0);
  }

function keyTypes(){
	if (key=='s'){save("big-hero-6.png")}
}