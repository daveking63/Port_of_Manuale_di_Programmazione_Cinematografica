// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/fifth_element_the
// Date: 2016
// Description: The Fifth Element (1997)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(255, 173, 96);
	INK = color(240);
	noLoop();
}

function draw() {
	background(PAPER);

	let s = float(min(width, height) / 8.0);

	fill(PAPER);
	stroke(INK);
	strokeWeight(s);
	translate(width/2.0, 0);
	line(0, 0, 0, height);
	ellipse(0, 0, 4*s, 4*s);

	translate(0, height/3.0);

	for (let i=0; i<3; i++) {
		line(-width/2.0, 0, width/2.0, 0);
		translate(0, height/4.0);
	}

	resetMatrix();
	translate(width/2.0, height);

	ellipse(-width/2.0, 0, width, height/3.0);
	ellipse( width/2.0, 0, width, height/3.0);
  
}
function keyTypes(){
	if (key=='s'){save("the-fifth-element.png")}
}