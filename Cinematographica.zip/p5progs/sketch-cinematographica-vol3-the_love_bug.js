// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/love_bug_the
// Date: 2015
// Description: The love bug (1968)

let PAPER;
let INK1;
let INK2;
let INK3;
let f;

function preload(){
	f = loadFont('data/FiraMono-Bold.otf');
}

function setup() {
	createCanvas(480, 640);
	PAPER = color (240, 240, 240);
	INK1 = color(200, 50, 55);
	INK2 = color(20, 80,135);
	INK3 = color(30, 30, 30);
	noLoop();
}

function draw() {
	background(PAPER);

	stroke(INK1);
	strokeWeight(25.0);
	line(2*width/3.0, 0, 2*width/3.0, height);

	stroke(INK2);
	strokeWeight(50.0);
	line(2*width/3.0+50, 0, 2*width/3.0+50, height);

	stroke(INK3);
	strokeWeight(2.0);
	ellipse(2*width/3.0, height/3.0+5, 124, 124);

	fill(INK3);
	textFont(f);
	textSize(60);
	textAlign(CENTER, CENTER);
	text("53", 2*width/3.0, height/3.0);
}

function keyTypes(){
	if (key=='s'){save("the-love-bug.png")}
}