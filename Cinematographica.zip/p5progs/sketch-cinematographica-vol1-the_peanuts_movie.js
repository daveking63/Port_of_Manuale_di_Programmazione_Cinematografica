// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/peanuts_movie_the
// Date: 2016
// Description: The Peanuts Movie

let PAPER;
let INK1;
let INK2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(245, 220, 110);
	INK1 = color(180, 50, 50);
	INK2 = color(40);
	noLoop();
}

function draw() {
	background(PAPER);

	let s = float(min(width, height) / 480.0);

	translate(width/2.0, 2*height/3.0);
	scale(s);
	fill(INK1);
	strokeWeight(2.0);
	stroke(INK2);

	rectMode(CENTER);
	rect(0, 0, 200, 150);

	translate(0, -120);
	quad(-100, -100, 100, -100, 150, 100, -150, 100);

}
function keyTypes(){
	if (key=='s'){save('the-peanuts-movie.png')}
}