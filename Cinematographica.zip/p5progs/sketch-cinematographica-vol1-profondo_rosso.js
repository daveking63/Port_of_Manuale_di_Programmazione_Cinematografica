// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/profondo_rosso
// Date: 2016
// Description: Profondo Rosso (1975)

let PAPER;

function setup() {
	createCanvas(480, 640);
	PAPER = color(190, 0, 50);
	noLoop();
}

function draw() {
  background(PAPER);
}

function keyTypes(){
	if (key=='s'){save('profondo-rosso.png')}
}
