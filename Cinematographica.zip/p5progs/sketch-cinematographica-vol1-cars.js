// Source: Manuale di Programmazione Cinematografica - Volume 1
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume1/cars
// Date: 2016
// Description: Cars (2006)

let L = 0.8;
let D = 0.1*L;

function setup() {
	createCanvas(480, 640);
	PAPER = color(205, 40, 10);
	INK = color(255);
	noLoop();
}

function draw() {
	background(PAPER);
	let F = min(width, height);

	translate(0.5*width, 0.5*height);
	scale(F);
	fill(INK);
	noStroke();

	arc(0.00  , 0.00, 1.00*L, 0.40*L, PI, TWO_PI-(0.5*QUARTER_PI), CHORD);
	arc(0.20*L, 0.00, 0.55*L, 0.65*L, PI+(0.5*QUARTER_PI), TWO_PI-(0.3*QUARTER_PI), CHORD);

	fill(PAPER);

	ellipse(-1.3*D, -1.0*D, D, D);
	ellipse( 1.3*D, -1.3*D, D, D);
  
}
function keyTypes(){
	if (key=='s'){save('("cars.png")')}
}