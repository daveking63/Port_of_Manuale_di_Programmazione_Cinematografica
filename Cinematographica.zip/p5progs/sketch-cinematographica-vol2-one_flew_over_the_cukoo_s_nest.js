// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/one_flew_over_the_cuckoo_s_nest
// Date: 2015
// Description: One flew over the cukoo's nest (1975)

let PAPER;
let INK;
let SIZE = 250;

function setup() {
	createCanvas(480, 640);
	PAPER = color(240, 240, 240);
	INK = color(30, 30, 30);
	noLoop();
}

function draw() {
	background(PAPER);

	translate(width/2.0, height/2.0);
	fill(INK);
	noStroke();

	ellipseMode(CENTER);
	arc(0, -0.05*SIZE, SIZE, SIZE, -PI, 0);

	rectMode(CENTER);
	rect(0, 0.05*SIZE, 1.05*SIZE, 0.25*SIZE, 10);
}
function keyTypes(){
	if (key=='s'){save("one-flew-over-the-cukoo-s-nest.png")}
}