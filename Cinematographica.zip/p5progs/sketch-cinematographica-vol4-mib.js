// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/mib
// Date: 2017
// Description: MIB (1997)

let PAPER;
let INK1;
let INK2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0);
	INK1 = color(240);
	INK2 = color(170, 10, 45);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let s = float(0.1 * min(width, height));

	translate(0.5*width, 0.25*height);
	fill(INK2);
	stroke(INK1);
	strokeWeight(s);
	line(0, 0, 0, 7*s);

	strokeWeight(0.2*s);
	rectMode(CENTER);
	rect(0, 0.5*s, 1.2*s, 0.7*s, s);
}

function keyTypes(){
	if (key=='s'){save("mib.png")}
}