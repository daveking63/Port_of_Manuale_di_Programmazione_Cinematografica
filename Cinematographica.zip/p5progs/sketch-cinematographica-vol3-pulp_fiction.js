// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/pulp_fiction
// Date: 2015
// Description: Pulp Fiction (1994)


let PAPER;
let INK;
let SPOTS = 1000;

function setup() {
	createCanvas(480, 640);
	PAPER = color(80, 80, 80);
	INK = color(220, 50, 50);
	noLoop();
}

function draw() {
	background(PAPER);
	
	translate(width/2.0, height/2.0);
	fill(INK);
	noStroke();
	ellipseMode(CENTER);

	for (let i=0; i<SPOTS; i++) {
		let x = float((width/5.0)*randomGaussian());
		let y = float((height/5.0)*randomGaussian());
		let r = float(((width-abs(x)-abs(y))/25.0)*randomGaussian());
		ellipse(x, y, r, r);
	}
}

function keyTypes(){
	if (key=='s'){save("pulp-fiction.png")}
}
