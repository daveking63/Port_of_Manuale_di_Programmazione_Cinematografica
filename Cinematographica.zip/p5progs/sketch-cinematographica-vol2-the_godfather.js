// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/godfather_the
// Date: 2016
// Description: The Godfather (1972)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(10);
	INK = color(240);
	noLoop();
}


function draw() {
	background(PAPER);

	fill(INK);
	noStroke();
	triangle(0.15*width, 0, 0.85*width, 0, 0.5*width, 1.4*height);

	fill(PAPER);
	translate(width/2.0, height/4.0);

	let sx = float(min(width, height) / 4.8);
	let sy = float(sx / 2.0);

	beginShape();
		vertex(-sx, -sy);
		vertex( sx,  sy);
		vertex( sx, -sy);
		vertex(-sx,  sy);
	endShape();

}
function keyTypes(){
	if (key=='s'){save("the-godfather.png")}
}