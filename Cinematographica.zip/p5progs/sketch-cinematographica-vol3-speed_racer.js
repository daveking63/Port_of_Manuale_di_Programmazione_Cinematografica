// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/speed_racer
// Date: 2015
// Description: Speed Racer (2008)

let PAPER;
let INK;
let SIZE = 40;


function setup() {
	createCanvas(480, 640);
	PAPER = color(230, 165, 25);
	INK = color(225, 40, 45);
	noLoop();
}

function draw() {
	background(PAPER);

	fill(INK);
	noStroke();

	for (let i=0; i<width/SIZE; i++) {
		for (let j=0; j<height/SIZE; j++) {
			if ((i+j)%2 == 0) {
				rect(i*SIZE, j*SIZE, SIZE, SIZE);
			}
		}
	}
}

function keyTypes(){
	if (key=='s'){save("speed-racer.png")}
}