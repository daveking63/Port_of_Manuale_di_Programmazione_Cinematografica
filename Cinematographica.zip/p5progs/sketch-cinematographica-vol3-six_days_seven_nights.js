// Source: Manuale di Programmazione Cinematografica - Volume 3
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume3/six_days_seven_nights
// Date: 2015
// Description: Six Days Seven Nights (1998)

let PAPER;
let INK1;
let INK2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(96, 78, 151);
	INK1 = color(255, 255, 0);
	INK2 = color(244, 243, 242);
	noLoop();
}

function draw() {
	background(PAPER);
	let phase = 1;
	translate(width/2.0, 0);

	for (let j=0; j<2; j++) {
		for (let i=-1; i<2; i++) {
			drawSun(i*120, 100+j*110, 40, 8);
			drawMoon(i*120, 320+j*110, 60, phase++);
		}
	}

	drawMoon(0, 540, 60, 8);
}

function drawSun(x, y, r, rays) {
	fill(INK1);
	stroke(INK1);
	strokeWeight(r/6.0);

	push();
	translate(x, y);
	ellipseMode(CENTER);
	ellipse(0, 0, r, r);
	let offset = float(r/2.0 + r/4.0);
	for (let i=0; i<=rays; i++) {
		line(offset, 0, offset+r/2.0, 0);
		rotate(TWO_PI / rays);
	}
	pop();
}

function drawMoon(x, y, r, phase) {
	push();
		translate(x, y);
		rotate(HALF_PI/2.0);
		fill(INK2);
		noStroke();
		ellipseMode(CENTER);
		arc(0, 0, r, r, 0, PI, OPEN);
		fill((phase<4) ? PAPER : INK2);
		let offset = float(abs(r/4 * (phase-4)));
		let angle = float((phase < 4) ? 0 : PI);
		arc(0, 0, r, offset, angle, angle+PI+1, OPEN);
	pop();
}

function keyTypes(){
	if (key=='s'){save("six-days-seven-nights.png")}
}
