// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/stargate
// Date: 2017
// Description: Stargate (1994)

// Action, Adventure, Sci-Fi
// http://www.imdb.com/title/tt0111282

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(50, 60, 70);
	INK = color(90, 115, 140);
	noLoop();
}

function draw() {
	background(PAPER);
	let S = float(min(width, height));
	let U = 0.002;

	translate(0.5*width, 0.3*height);
	scale(S);
	noFill();
	stroke(INK);
	strokeCap(SQUARE);
	strokeWeight(25*U);

	beginShape();
		vertex(-0.23, 0.48);
		vertex(-0.22, 0.50);
		vertex(-0.25, 0.50);
		vertex( 0.00, 0.00);
		vertex( 0.25, 0.50);
		vertex( 0.22, 0.50);
		vertex( 0.23, 0.48);
	endShape();

	strokeWeight(12*U);
	ellipse(0.00, -0.14, 0.08, 0.08);
}

function keyTypes(){
	if (key=='s'){save("stargate.png")}
}  