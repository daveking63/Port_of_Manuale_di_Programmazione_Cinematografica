// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/ninth_gate_the
// Date: 2017
// Description: The Ninth Gate (1999)

let PAPER;
let INK;
let A;
let T = 0.05;
let L1 = 0.4;
let L2;

function setup() {
	createCanvas(480, 640);
	PAPER = color(0);
	INK = color(250, 180, 50);
	A = TWO_PI / 5.0;
	L2 = L1 - (T / tan(0.25*A));
	noLoop();
}

function draw() {
	background(PAPER);

	let S =  float(min(width, height));
	let U = 0.002;
	let D = float(100.0*T*U);

	translate(0.5*width, 0.5*height);
	scale(S);

	for (let i=0; i<11; i++) {
		noStroke();
		fill(PAPER);
		quad(L2, 0, 0, 0, 0, T, L1, T);
		stroke(INK);
		strokeWeight(D);
		line(L2, 0, 0, 0);
		line(L1, T, 0, T);
		scale(-1, 1);
		if (i%2 != 0) {
			translate(L2+0.5*D, 0);
			rotate(-2*A);
			translate(L2+0.5*D, 0);
		}
	} 
}

function keyTypes(){
	if (key=='s'){save("the-ninth-gate.png")}
}  