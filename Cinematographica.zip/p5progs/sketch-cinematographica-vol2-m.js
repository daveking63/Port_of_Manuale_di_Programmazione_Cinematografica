// Source: Manuale di Programmazione Cinematografica - Volume 2
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume2/m
// Date: 2015
// Description: M (1931)

let PAPER;
let INK;

function setup() {
	createCanvas(480, 640);
	PAPER = color(250, 185, 105);
	INK = color(245, 50, 15);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let d = float(min(width, height) / 8.0);

	translate(width/2.0, height/3.0);
	stroke(INK);
	strokeWeight(d/1.5);

	line(-d, 0,  0, d);
	line( d, 0,  0, d);
	line(-d, 0, -d, 2.5*d);
	line( d, 0,  d, 2.5*d);
}

function keyTypes(){
	if (key=='s'){save("M.png")}
}