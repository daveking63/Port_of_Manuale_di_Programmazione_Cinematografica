// Source: Manuale di Programmazione Cinematografica - Volume 5
// Artist: Daniele Olmisani
// SourceType: Code at // SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume5/aquaman
// Date: 2019
// Description: Aquaman (2018)

let INK1, INK2, INK3, INK4

function setup() {
  createCanvas(480, 640);
  INK1 = color(240, 135, 20);
  INK2 = color(15, 140, 60);
  INK3 = color(255, 210, 20);
  INK4 = color(0);
  noLoop();
}


function draw() {
  
  let S =  float(min(width, height));
  let U =  0.002;
  
  translate(0.5*width, 0.5*height);
  scale(S);
  
  noStroke();
  rectMode(CENTER);
  
  fill(INK1);
  rect(0.0, -0.5, 1.0, 1.0);
  
  fill(INK2);
  rect(0.0, 0.5, 1.0, 1.0);
  
  fill(INK3);
  strokeWeight(3*U);
  stroke(INK4);
  rect(0.0, 0.0, 1.5, 0.15);
  
  fill(INK3);
  triangle(0.0, -0.2, -0.2, 0.2, 0.2, 0.2);
  
  fill(INK2);
  arc(0.0, 0.2, 0.1, 0.1, -PI, 0.0, OPEN);
  
  stroke(INK2);
  line(-0.045, 0.2, 0.045, 0.2);
}

function keyTypes(){
	if (key=='s'){save('aquaman.png')}
}