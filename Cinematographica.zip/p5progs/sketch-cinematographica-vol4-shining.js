// Source: Manuale di Programmazione Cinematografica - Volume 4
// Artist: Daniele Olmisani
// SourceType: Code at https://github.com/mad4j/book-mdpc/tree/master/examples/volume4/shining
// Date: 2017
// Description: Shining (1980)

// Drama, Horror
// http://www.imdb.com/title/tt0081505/

let PAPER;
let INK;
let P = "fflfflfrfrfrfrfrflffl ffrffrflflflflflfrffr";

function setup() {
	createCanvas(480, 640);
	PAPER = color(240, 90, 40);
	INK = color(0);
	noLoop();
}

function draw() {
	background(PAPER);
	
	let S = float(min(width, height));
	let U = 0.002;
	let dL = 0.05;
	let dA = PI/3.0;

	scale(S);
	translate(-dL, -dL);
	stroke(INK);
	strokeWeight(10*U);

	for (let k=0; k<7; k++) {
		push();
			rotate(-PI/6.0);
			for (let i=0; i<7; i++) {
				drawTurtle(P, dL, dA);
			}
		pop();
		
		translate(0.0, 5*dL);
	}
}

function drawTurtle(path, dL, dA) {
	for (let i=0; i<path.length; i++) {
		let c = path.charAt(i);
		switch (c) {
			case 'f':
				line(0, 0, dL, 0);
				translate(dL, 0);
				break;
			case 'r':
				rotate(dA);
				break;
			case 'l':
				rotate(-dA);
				break;
			default:
		}
	}
}

function keyTypes(){
	if (key=='s'){save("shining.png")}
}  